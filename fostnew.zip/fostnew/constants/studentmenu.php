
<aside class="fixed skin-6">
    <div class="sidebar-inner scrollable-sidebar">
        <div class="size-toggle">
            <a class="btn btn-sm" id="sizeToggle">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </a>
            <a class="btn btn-sm pull-right logoutConfirm_open"  href="#logoutConfirm">
                <i class="fa fa-power-off"></i>
            </a>
        </div><!-- /size-toggle --> 
        <div class="user-block clearfix">
            <div class="detail">
                <strong>Logged as <?php echo strtoupper($fname);?></strong><span class="badge badge-danger m-left-xs bounceIn animation-delay4"></span>
            </div>
        </div><!-- /user-block -->
        <div class="main-menu">
            <ul>
                <li class="">
                    <a href="stdhome.php?id=<?php echo $accessnooo;?>">
                        <span class="menu-icon">
                            <i class="glyphicon glyphicon-home fa-lg"></i> 
                        </span>
                        <span class="text">
                            Home
                        </span>
                    </a>
                </li>              
                <li class="">
                    <a href="myresults.php?id=<?php echo $accessnooo;?>">
                        <span class="menu-icon">
                            <i class="glyphicon glyphicon-print fa-lg"></i> 
                        </span>
                        <span class="text">
                            Results Printout
                        </span>
                    </a>
                </li>
                <!--
                <li class="">
                    <a href="importmarks.php">
                        <span class="menu-icon">
                            <i class="glyphicon glyphicon-hand-right fa-lg"></i> 
                        </span>
                        <span class="text">
                            Enter Results
                        </span>
                    </a>
                </li>
                <li class="">
                    <a href="results.php">
                        <span class="menu-icon">
                            <i class="glyphicon glyphicon-hand-right fa-lg"></i> 
                        </span>
                        <span class="text">
                            View Results
                        </span>
                    </a>
                </li>
                <li class="">
                    <a href="files.php">
                        <span class="menu-icon">
                            <i class="glyphicon glyphicon-folder-open fa-lg"></i> 
                        </span>
                        <span class="text">
                            Files
                        </span>
                    </a>
                </li>
        -->
                <li class="">
                    <a href="file.php?id=<?php echo $accessnooo;?>">
                        <span class="menu-icon">
                            <i class="glyphicon glyphicon-folder-open"></i> 
                        </span>
                        <span class="text">
                            Find Files
                        </span>
                    </a>
                </li>
                <li class="">
                    <a href="stdprofile.php?id=<?php echo $accessnooo;?>">
                        <span class="menu-icon">
                            <i class="glyphicon glyphicon-user fa-lg"></i> 
                        </span>
                        <span class="text">
                            My Account
                        </span>
                    </a>
                </li>
            
            </ul>
            
        </div><!-- /main-menu -->
    </div><!-- /sidebar-inner -->
</aside>