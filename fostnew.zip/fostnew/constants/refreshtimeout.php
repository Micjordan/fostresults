//refresh page if no activity in 60 seconds
<meta http-equiv="refresh" content="60;url=http://fost-ucu.ucu.ac.ug/fostresults" />