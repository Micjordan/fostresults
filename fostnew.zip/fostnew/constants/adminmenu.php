<?php
include('dbconfig.php');
?>
<script type="text/javascript">
    function resultsClick(){
        //alert('moses');
        //document.getElementById('reportDiv').inHTML = "";
        //document.getElementById('btnPrint').style.opacity = 1;
        var yearofentry = btoa(document.getElementById('yearofentryzz').value);
        var program = btoa(document.getElementById('programzz').value);
        //var pro = document.getElementById('programzz').value.innerHTML;
        // alert (yearofentry+"     and program is     =   "+program);
        //alert(pro);
        if (yearofentry.length > 0 && program.length > 0 ) {
            /*
            $( "#main-container" ).load( "results.php", { yearofentry: yearofentry , program: program }, function() {
              //alert( "Program "+program+" was loaded for the year of entry = "+yearofentry );
            });
            */
            var url = "results.php?yearofentry="+yearofentry+"&program="+program;
            //$(location).attr('href', url);
            //window.location = "results.php?yearofentry="+yearofentry+"&program="+program;
            location.href = url;
        }else{
            alert("Sorry! Invalid Program or Year of Entry");
        }         
    }
    function myFunctionChanged(){
        alert("one");
    }
</script>
<aside class="fixed skin-6">
            <div class="sidebar-inner scrollable-sidebar">
                <div class="size-toggle">
                    <a class="btn btn-sm" id="sizeToggle">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </a>
                    <a class="btn btn-sm pull-right "  href="die.php">
                        <i class="fa fa-power-off"></i>
                    </a>
                </div><!-- /size-toggle --> 
                <div class="user-block clearfix">
                     <div class="detail">
                        <strong>

                               <?php 

                                    //include('dbconfig.php');

                                    $uid = $_SESSION["id"];

                                    $result = $conn -> query("SELECT username from users where userid='$uid'");

                                    $row =  mysqli_fetch_array($result);

                                    echo $row['username'];
//$_SESSION["username"];
                                ?> 

                         Signed In</strong><span class="badge badge-danger m-left-xs bounceIn animation-delay4"></span>
                    </div>
                </div><!-- /user-block -->
                <div class="main-menu">
                    <ul>
                        <li>
                            <a href="reports.php">
                                <span class="menu-icon">
                                    <i class="fa fa-desktop fa-lg"></i> 
                                </span>
                                <span class="text">
                                    Reports
                                </span>
                                <span class="menu-hover"></span>
                            </a>
                        </li>
                        <li class="">
                            <a href="lectureadd.php">
                                <span class="menu-icon">
                                    <i class="glyphicon glyphicon-tags fa-lg"></i> 
                                </span>
                                <span class="text">
                                    Lecturer
                                </span>
                            </a>
                        </li>  
                        <li class="">
                            <a href="courseunits.php">
                                <span class="menu-icon">
                                    <i class="glyphicon glyphicon-file fa-lg"></i> 
                                </span>
                                <span class="text">
                                    Program / CourseUnit
                                </span>
                            </a>
                        </li>                  

                        <li class="">
                            <a href="students.php">
                                <span class="menu-icon">
                                    <i class="glyphicon glyphicon-user fa-lg"></i> 
                                </span>
                                <span class="text">
                                    Students
                                </span>
                            </a>
                        </li>
                        
                        <li class="">
                            <!--
                                <a class="clearfix" role="button" data-toggle="modal" href="#stats" >
                                <a href="results.php">
                                    <span class="menu-icon">
                                        <i class="glyphicon glyphicon-hand-right fa-lg"></i> 
                                    </span>
                                    <span class="text">
                                        View Results
                                    </span>
                                </a>
                            -->
                            <a class="clearfix" role="button" data-toggle="modal" href="#resultspop">
                                <span class="menu-icon">
                                    <i class="glyphicon glyphicon-eye-open fa-lg"></i> 
                                </span>
                                <span class="text">
                                    View Results
                                </span>
                            </a>
                        </li>
                       
                        
                    </ul>
                    
                </div><!-- /main-menu -->
            </div><!-- /sidebar-inner -->
        </aside>


    <!--Modal-->
    <div class="modal fade" id="resultspop">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header modal-danger">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4>View Results</h4>
                </div>
                <div class="modal-body">
                    <form>
                        <div class="row">
                            <div class="form-group col-md-8">
                                <label for="exampleInputEmail1">Select Program</label>
                                <select id="programzz" class="form-control select" data-live-search="true" data-style="btn-default">
                                    <?php
                                        include('dbconfig.php');

                                        $sqlprograms = "SELECT `programcode`, `programname` FROM `programs`";
                                        $resultprograms = mysqli_query($conn, $sqlprograms);
                                        if(mysqli_num_rows($resultprograms) > 0){
                                            while ($row = mysqli_fetch_array($resultprograms)) {
                                                $program = $row['programname'];
                                                $programcode = $row['programcode'];
                                                echo "<option id=\"optionId\" value=\"".$programcode."\">".$program."</option>";
                                            }
                                        }
                                    ?>
                                </select>
                            </div>
                            <div class="form-group col-md-4">
                                <label for="exampleInputEmail1">Select Year of Entry</label>
                                <select id="yearofentryzz" class="form-control select" data-live-search="true" data-style="btn-default">
                                    
                                    <?php

                                        $sqlyears = "SELECT DISTINCT(`yearofentry`) AS yearofentry FROM students";
                                        $resultyears = mysqli_query($conn, $sqlyears);

                                        if(mysqli_num_rows($resultyears) > 0){
                                            while ($row = mysqli_fetch_array($resultyears)) {
                                                $year = $row['yearofentry'];
                                                echo "<option value=\"".$year."\">".$year."</option>";
                                            }
                                        }
                                    ?>
                                </select>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-lg btn-success" data-dismiss="modal" aria-hidden="true"><i class="fa fa-close"></i> Cancel</button>
                    
                    <a onclick="resultsClick()" data-dismiss="modal" class="btn btn-default btn-lg"><i class="fa fa-check"></i> Ok</a>
                    
                </div>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->