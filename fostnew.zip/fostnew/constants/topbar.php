
<div id="top-nav" class="fixed skin-6">
    <a href="#" class="brand" style="text-decoration:none;">
        <span><small></small></span>
        <span class="text-toggle"> FOST</span>
    </a><!-- /brand -->                 
    <button type="button" class="navbar-toggle pull-left" id="sidebarToggle">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
    </button>
    <button type="button" class="navbar-toggle pull-left hide-menu" id="menuToggle">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
    </button>
    <ul class="nav-notification clearfix">
        
        <li class="">
            <a>
                <!--<span><i class="fa fa-chevron-right"></i></span><strong> John Doe </strong>
                <span><i class="fa fa-chevron-left"></i></span>-->
            </a>
        </li>
        <li class="divider"></li>
        <li><a tabindex="-1" class="main-link " href="die.php"><i class="fa fa-lock fa-lg"></i> Log out</a></li>
    </ul>
</div>
    