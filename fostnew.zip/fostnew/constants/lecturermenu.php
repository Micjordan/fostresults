<?php
include('dbconfig.php');
?>
<script type="text/javascript">
    function resultsClick(){
        //alert('moses');
        //document.getElementById('reportDiv').inHTML = "";
        //document.getElementById('btnPrint').style.opacity = 1;
        var yearofentry = btoa(document.getElementById('yearofentryzz').value);
        var program = btoa(document.getElementById('programzz').value);
        //var pro = document.getElementById('programzz').value.innerHTML;
        // alert (yearofentry+"     and program is     =   "+program);
        //alert(pro);
        if (yearofentry.length > 0 && program.length > 0 ) {
            /*
            $( "#main-container" ).load( "results.php", { yearofentry: yearofentry , program: program }, function() {
              //alert( "Program "+program+" was loaded for the year of entry = "+yearofentry );
            });
            */
            var url = "lectresults.php?yearofentry="+yearofentry+"&program="+program;
            //$(location).attr('href', url);
            //window.location = "results.php?yearofentry="+yearofentry+"&program="+program;
            location.href = url;
        }else{
            alert("Sorry! Invalid Program or Year of Entry");
        }         
    }
    function myFunctionChanged(){
        alert("one");
    }
</script>
<aside class="fixed skin-6">
            <div class="sidebar-inner scrollable-sidebar">
                <div class="size-toggle">
                    <a class="btn btn-sm" id="sizeToggle">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </a>
                    <a class="btn btn-sm pull-right "  href="die.php">
                        <i class="fa fa-power-off"></i>
                    </a>
                </div><!-- /size-toggle --> 
                <div class="user-block clearfix">
                    <div class="detail">
                        <strong>

                               <?php 

                                    

                                    $uid = $_SESSION["id"];

                                    $result = $conn -> query("SELECT name from users where userid='$uid'");

                                    $row =  mysqli_fetch_array($result);

                                    echo $row['name'];
//$_SESSION["username"];
                                ?> 

                         Signed In</strong><span class="badge badge-danger m-left-xs bounceIn animation-delay4"></span>
                    </div>
                </div><!-- /user-block -->
                <div class="main-menu">
                    <ul>
                                         

                        <li class="">
                            <a href="lecturestudents.php">
                                <span class="menu-icon">
                                    <i class="glyphicon glyphicon-cog fa-lg"></i> 
                                </span>
                                <span class="text">
                                    Students
                                </span>
                            </a>
                        </li>
                        <li class="">
                            <a href="importcwmarks.php">
                                <span class="menu-icon">
                                    <i class="glyphicon glyphicon-pencil fa-lg"></i> 
                                </span>
                                <span class="text">
                                    Enter CW Results
                                </span>
                            </a>
                        </li>
                         <li class="">
                            <a href="importexmarks.php">
                                <span class="menu-icon">
                                    <i class="glyphicon glyphicon-pencil fa-lg"></i> 
                                </span>
                                <span class="text">
                                    Enter Exam Results
                                </span>
                            </a>
                        </li>
                    <!--     <li class="">
                            <a href="finalmarks.php">
                                <span class="menu-icon">
                                    <i class="glyphicon glyphicon-book fa-lg"></i> 
                                </span>
                                <span class="text">
                                    Submit Total/Final Mark
                                </span>
                            </a>
                        </li> -->
                        <li class="">                         
                            <a href="lectresults.php">
                                <span class="menu-icon">
                                    <i class="glyphicon glyphicon-eye-open fa-lg"></i> 
                                </span>
                                <span class="text">
                                    View Marks
                                </span>
                            </a>
                        </li>
                        
                      <!--   <li class="">
                            <a href="files.php">
                                <span class="menu-icon">
                                    <i class="glyphicon glyphicon-folder-open fa-lg"></i> 
                                </span>
                                <span class="text">
                                    Files
                                </span>
                            </a>
                        </li>
                        <li class="">
                            <a href="filesstudent.php">
                                <span class="menu-icon">
                                    <i class="glyphicon glyphicon-folder-open fa-lg"></i> 
                                </span>
                                <span class="text">
                                    Files (students view)
                                </span>
                            </a>
                        </li> -->
                         <li class="">
                            <a href="lectprofile.php">
                                <span class="menu-icon">
                                    <i class="glyphicon glyphicon-user fa-lg"></i> 
                                </span>
                                <span class="text">
                                    Profile
                                </span>
                            </a>
                        </li>
                    </ul>
                    
                </div><!-- /main-menu -->
            </div><!-- /sidebar-inner -->
        </aside>
<?php

        $try = $_SESSION["id"];
            $sqlselectedcourse = "SELECT `coursename`, `coursecode` FROM `courses` WHERE `userid` = '".$try."'";
            
            $resultcosname = mysqli_query($conn,$sqlselectedcourse);
            while ($row = mysqli_fetch_array($resultcosname)) {
                $selectedcoursename = $row['coursename'];
                $selectedcode = $row['coursecode'];
            }?>
    <!--Modal-->
    <div class="modal fade" id="resultspop">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header modal-danger">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4>View Marks</h4>
                </div>
                <div class="modal-body">
                    <form>
                        <div class="row">
                            <div class="form-group col-md-8">
                                <label for="exampleInputEmail1">Select Course</label>
                                <select id="programzz" class="form-control select" data-live-search="true" data-style="btn-default">
                                    <?php
                                        

                                        $sqlcos = "SELECT `coursename`, `coursecode` FROM `courses` WHERE `userid` = '".$try."'";
                                        $resultcos = mysqli_query($conn, $sqlcos);
                                        if(mysqli_num_rows($resultcos) > 0){
                                            while ($row = mysqli_fetch_array($resultcos)) {
                                                $cos = $row['coursename'];
                                                $cod = $row['coursecode'];
                                                echo "<option id=\"optionId\" value=\"".$cod."\">".$cos."</option>";
                                            }
                                        }
                                    ?>
                                </select>
                            </div>
                           <div class="form-group col-md-4">
                                <label for="exampleInputEmail1">Select Year of Entry</label>
                                <select id="yearofentryzz" class="form-control select" data-live-search="true" data-style="btn-default">
                                    
                                   <?php

                                        $sqlyears = "SELECT DISTINCT(`yearofentry`) AS yearofentry FROM students";
                                        $resultyears = mysqli_query($conn, $sqlyears);

                                        if(mysqli_num_rows($resultyears) > 0){
                                            while ($row = mysqli_fetch_array($resultyears)) {
                                                $year = $row['yearofentry'];
                                                echo "<option value=\"".$year."\">".$year."</option>";
                                            }
                                        }
                                    ?>
                                </select>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-lg btn-success" data-dismiss="modal" aria-hidden="true"><i class="fa fa-close"></i> Cancel</button>
                    
                    <a onclick="resultsClick()"
                     data-dismiss="modal" class="btn btn-default btn-lg"><i class="fa fa-check"></i> Ok</a>
                    
                </div>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->