<?php
	ob_start();
	session_start();
    if (isset($_SESSION["id"]) && isset($_SESSION['administrator'])) {
		echo "<script>window.open('lectureadd.php','_self')</script>";
	}
	if (isset($_SESSION["id"]) && isset($_SESSION['student'])) {
		echo "<script>window.open('myresults.php.php','_self')</script>";
	}
	if (isset($_SESSION["id"]) && isset($_SESSION['lecturer'])) {
		echo "<script>window.open('importcwmarks.php','_self')</script>";
	}	
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>Login</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

	   <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
	   
		<link href="http://code.ionicframework.com/ionicons/2.0.0/css/ionicons.min.css" rel="stylesheet" type="text/css" />    

    <!-- Bootstrap core CSS -->
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
	
	<!-- Font Awesome -->
	<link href="css/font-awesome.min.css" rel="stylesheet">
	
	<!-- Endless -->
	<link href="css/endless.css" rel="stylesheet">
	
		        
  </head>




  <body id="bodyy" style="min-height:100%; background:linear-gradient(40deg,rgba(20,20,15,1),rgba(2,0,150,1)),url(img/backgrounds/pexels.jpg); background-size:cover;">
	<div class="login-wrapper">
		<div class="login-widget">
			<div class="panel panel-default mine">
				<div class="panel-heading clearfix text-center mine2">
					<img src="img/uculogo.png">
				</div>
				<div class="text-center">
					<h2 class="fade fadeInDown animation-delay2" style="font-weight:bold; color:#000; text-shadow:0 1px #fff">
						<span class="text-success"></span>Results Management Tool <span></span>
					</h2>
				</div>
			</div>
		</div>
		<div class="login-widget animation-delay1">	
			<div class="panel panel-default mine">
				<div class="panel-heading clearfix mine2">
					<div class="pull-left">
						<i class="fa fa-lock fa-lg"></i> Login
					</div>

					<div class="pull-right">
						<span style="font-size:11px;">Enter your details Below</span>
						<!--
						<a class="btn btn-default btn-xs login-link" href="register.html" style="margin-top:-2px;"><i class="fa fa-plus-circle"></i> Sign up</a>
						-->
					</div>
				</div>
				<div class="panel-body">
					<form class="form-login" action="verify.php" method="post">
						<div class="form-group">
							<label>Username</label>
							<input type="text" placeholder="Username" name="username" class="form-control input-sm bounceIn animation-delay2" required="" >
						</div>
						<div class="form-group">
							<label>Password</label>
							<input type="password" placeholder="Password" name="password" class="form-control input-sm bounceIn animation-delay4" required="">
						</div>
						<!--
						<div class="form-group">
							<label class="label-checkbox inline">
								<input type="checkbox" class="regular-checkbox chk-delete" />
								<span class="custom-checkbox info bounceIn animation-delay4"></span>
							</label>
							Remember me		
						</div>
						-->
						<div class="seperator"></div>
						<!--
						<div class="form-group">
							Forgot your password?<br/>
							Click <a href="#">here</a> to reset your password
						</div>
						-->
						<hr/>
							
						<button class="btn btn-default btn-sm bounceIn animation-delay5 pull-left" type="reset"><i class="fa fa-sign-out"></i> Clear</button>	
						<button class="btn btn-default btn-sm bounceIn animation-delay5 pull-right" type="submit"><i class="fa fa-sign-in"></i> Sign in</button>
					</form>
				</div>
			</div><!-- /panel -->
		</div><!-- /login-widget -->
	</div><!-- /login-wrapper -->

    <!-- Le javascript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    
    <!-- Jquery -->
	<script src="js/jquery-1.10.2.min.js"></script>
    
    <!-- Bootstrap -->
    <script src="bootstrap/js/bootstrap.min.js"></script>
   
	<!-- Modernizr -->
	<script src='js/modernizr.min.js'></script>
   
    <!-- Pace -->
	<script src='js/pace.min.js'></script>
   
	<!-- Popup Overlay -->
	<script src='js/jquery.popupoverlay.min.js'></script>
   
    <!-- Slimscroll -->
	<script src='js/jquery.slimscroll.min.js'></script>
   
	<!-- Cookie -->
	<script src='js/jquery.cookie.min.js'></script>

	<!-- Endless -->
	<script src="js/endless/endless.js"></script>
  </body>
</html>
