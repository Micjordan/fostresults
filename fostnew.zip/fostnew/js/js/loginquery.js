$(document).ready(function () {
	$('.login').click(function () {

		var lusername = $('.lusername').val();
		var lpassword = $('.lpassword').val();

		window.alert("sometext");
			$('.lusername').keyup(function () {
				$('.lusernamemsg').text('');
			});	
			$('.lpassword').keyup(function () {
				$('.lpasswordmsg').text('');
			});	

		if (lusername=='') {
			$('.lusernamemsg').text('Provide Your Username').css('color','#0000FF');
		}
		else if (lpassword=='') {
			$('.lpasswordmsg').text('Provide Your Password').css('color','#0000FF');	
		}

		else{

			$.post('includes/loginquery.php',{lusername:lusername,lpassword:lpassword},function (data) {
				$('.loginmsg').html(data);
				$('.loginmsg').html(data).fadeOut(5000);
			});

			$('.lusername').val('');
			$('.lpassword').val('');
		
		}

	});
});