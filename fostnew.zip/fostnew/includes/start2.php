<!--banner-->
<section id="banner" class="banner">
	<div class="bg-color">
		<nav class="navbar navbar-default navbar-fixed-top conditional">
		  <div class="container">
		  	<div class="col-md-12">
			    <div class="navbar-header">
			      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
			        <span class="icon-bar"></span>
			        <span class="icon-bar"></span>
			        <span class="icon-bar"></span>
			      </button>
			    </div>				    
			</div>
		  </div>
		</nav>
		<div class="container">
			<div class="row">
				<div class="col-md-6 col-md-offset-3">
					<div class="banner-info">
						<div class="banner-logo text-center">
							<img src="img/core/Icon.jpg" class="img-rounded img-responsive" style="width: 150px; height: 150px; transform: rotate(-45deg); margin-bottom: 10px;">
						</div>
						<div class="banner-text text-center" style="margin-top: 60px;">
							<h1 class="white" style="line-height: 18px;">
								Management Agency LTD<br><br>
								<i style="color: #0000FF; font-size: 20px; text-transform: lowercase;">for the finest service</i>
							</h1>														
						</div>						
						<div class="overlay-detail text-center">
							<div class="row">							
								<div class="col-md-5">

									<div class="input-group">
									<span class="input-group-addon br-radius-zero" style="color: #0000FF;"><i class="fa fa-user fa-2x"></i></span>
										<input type="text" placeholder="Username" class="form-control input-lg br-radius-zero lusername">
									</div>	
									<span class="lusernamemsg"></span>					
									
								</div>
								<div class="col-md-5">

									<div class="input-group">
									<span class="input-group-addon br-radius-zero" style="color: #0000FF;"><i class="fa fa-lock fa-2x"></i></span>
										<input type="password" placeholder="Password" class="form-control input-lg br-radius-zero lpassword">
									</div>
									<span class="lpasswordmsg"></span>

								</div>
								<div class="col-md-2">
									<button class="btn btn-primary btn-lg login"><i class="fa fa-sign-in fa-1x">&nbsp;</i>Login</button>
								</div>

							</div>
							<div class="row">
								<div class="col-md-11 col-md-offset-1">
								<br>
									<span class="loginmsg"></span>
								</div>
							</div>
							
			             </div>		
					</div>
				</div>				
			</div>
		</div>
	</div>
</section>
<!--/ banner-->

<!--footer-->
<footer id="footer">
	<div class="footer-line">
		<div class="container">
			<div class="row">
				<div class="col-md-12 text-center">
					&copy; Copyright Icon Management Agency Ltd 2017. All Rights Reserved
				</div>
			</div>
		</div>
	</div>
</footer>
<!--/ footer-->