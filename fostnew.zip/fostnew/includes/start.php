<div class="login-widget">
			<div class="panel panel-default mine">
				<div class="panel-heading clearfix text-center mine2">
					<img src="img/uculogo.png">
				</div>
				<div class="text-center">
					<h2 class="fade fadeInDown animation-delay2" style="font-weight:bold; color:#000; text-shadow:0 1px #fff">
						<span class="text-success"></span>Results Management Tool <span></span>
					</h2>
				</div>
			</div>
		</div>
		<div class="login-widget animation-delay1">	
			<div class="panel panel-default mine">
				<div class="panel-heading clearfix mine2">
					<div class="pull-left">
						<i class="fa fa-lock fa-lg"></i> Login
					</div>

					<div class="pull-right">
						<span style="font-size:11px;">Enter your details Below</span>
						<!--
						<a class="btn btn-default btn-xs login-link" href="register.html" style="margin-top:-2px;"><i class="fa fa-plus-circle"></i> Sign up</a>
						-->
					</div>
				</div>
				<div class="panel-body">
					
						<div class="form-group">
							<label>Username</label>
							
								<input type="text" placeholder="Username" class="form-control input-sm bounceIn animation-delay2 lusername" >
							
							<span class="lusernamemsg"></span>

						</div>

						<div class="form-group">
							<label>Password</label>
							
								<input type="text" placeholder="Password" class="form-control input-sm bounceIn animation-delay2 lpassword" >
							
							<span class="lpasswordmsg"></span>
						</div>						
						<div class="seperator"></div>
						<hr/>
						<button class="btn btn-default btn-sm bounceIn animation-delay5 pull-left" type="reset"><i class="fa fa-sign-out"></i> Clear</button>	
						<button class="btn btn-default btn-sm bounceIn animation-delay5 pull-right login" type="submit"><i class="fa fa-sign-in"></i> Sign in</button>
				
				</div>
			</div><!-- /panel -->
		</div><!-- /login-widget -->
