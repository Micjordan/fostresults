<?php

class Core extends Config
{
	public function LoginQuery($username,$password)
	{
		$password=sha1(md5($password));
		$admin=$this->icon->query("SELECT * FROM admin_tb WHERE username='$username' AND password='$password'");
		$cheka=$admin->num_rows;
		$geta=$admin->fetch_array();
		$user=$this->icon->query("SELECT * FROM users_tb WHERE username='$username' AND password='$password'");
		$cheku=$user->num_rows;
		$getu=$user->fetch_array();
		try {
			if ($cheka==1 && $geta['permission']=='Admin') {
				$_SESSION['username']=$username;
				$_SESSION['Admin']=$geta['permission'];
				echo "<script>window.open('index.php','_self')</script>";
			}
			else if ($cheku==1 && $getu['permission']=='User') {
				if ($getu['access']=='Yes') {
					$active=$this->icon->query("UPDATE users_tb SET status='Active' WHERE username='$username'");
					$captureu=$this->icon->query("INSERT INTO capture_tb SET username='$username', timeon=now()");
					$capture_id=$this->icon->query("SELECT capture_id FROM capture_tb WHERE username='$username' ORDER BY capture_id DESC");
					$cid=$capture_id->fetch_array();
					$_SESSION['username']=$username;
					$_SESSION['User']=$getu['permission'];
					$_SESSION['captureid']=$cid['capture_id'];
					echo "<script>window.open('index.php','_self')</script>";					
				}
				else{
					echo '
					<div class="alert alert-blue br-radius-zero">
					  <i class="fa fa-warning"></i> You have been blocked from loging in
					</div>
					';
				}
				
			}
			else{

				echo '
				<div class="alert alert-blue br-radius-zero">
				  <i class="fa fa-warning"></i> You either entered wrong username or password !
				</div>
				';
			}
		} catch (Exception $e) {
			$e->getMessage();
		}
	}


	public function CaptureuseroffQuery($captureid,$username)
	{
		$captureuoff=$this->icon->query("UPDATE capture_tb SET timeoff=now() WHERE capture_id='$captureid'");
		$deactive=$this->icon->query("UPDATE users_tb SET status='Deactive' WHERE username='$username'");
	}

	public function LogoutQuery()
	{		
		echo "<script>window.open('../index.php','_self')</script>";
		session_destroy();
		$this->CaptureuseroffQuery(@$_SESSION['captureid'],@$_SESSION['username']);
	}

	public function FetchlogincaptureQuery()
	{
		$fetchcp=$this->icon->query("SELECT capture_tb.username,capture_tb.timeon,capture_tb.timeoff,users_tb.names FROM capture_tb,users_tb WHERE capture_tb.username=users_tb.username ORDER BY capture_id DESC");
		?>
		<table class="table table-striped table-bordered table-responsive table-hover small">
			<tr>
				<th>Names</th>
				<th>Username</th>
				<th>Time/Date Online</th>
				<th>Time/Date Offline</th>
			</tr>
		
		<?php
		foreach ($fetchcp as $row) {
			echo "<tr>";
			echo "<td>".$row['names']."</td>";
			echo "<td>".$row['username']."</td>";
			echo "<td style='color: #008000;'>".$row['timeon']."</td>";
			echo "<td style='color: #FF0000;'>".$row['timeoff']."</td>";
			echo "</tr>";
		}
		?>
		</table>
		<?php
	}

	public function FetchAdminQuery($username)
	{
		$fetchad=$this->icon->query("SELECT * FROM admin_tb WHERE username!='$username' ORDER BY admin_id DESC");
		?>
		<div class="panel panel-red br-radius-zero">
		  <div class="panel-heading">Chat With Admin</div>
		  <div class="panel-body" style="height: 150px; overflow: auto; text-transform: capitalize;">
		  	<?php
			
			foreach ($fetchad as $row) {
				try {

					$user=$row['username'];
					echo "<strong id='".$user."' value='".$user."'>".$row['username']."<em style='color: #008000;'><i class='fa fa-user pull-right'></i></em>";
					echo "<script>
							$(document).ready(function(){
								$('#".$user."').hover(function(){
		    					$(this).css('cursor','pointer');
			    				});
			    				$('#".$user."').click(function () {												
			    					$('.chatbox').show(500);
			    					$('.auser').text('".$user."');

			    					  var profile = $(this).attr('value');
			    					  $.get('includes/messageajax.php',{profile:profile});
			    					  $.get('includes/readmessagequery.php',{profile:profile});
						              $.get('includes/sendmessagequery.php',{profile:profile});
								});
								$('.closechat').hover(function(){
		    					$(this).css('cursor','pointer');
			    				});
								$('.closechat').click(function(){
			    					$('.chatbox').hide(500);
			    				});
							});
						</script>";
					
				} catch (Exception $e) {
					$e->getMessage();
				}
			}
			
			?>
		  </div>
		</div>	

		<?php
	}


	public function FetchUserQuery($username)
	{
		$fetchcp=$this->icon->query("SELECT * FROM users_tb WHERE status='Active' ORDER BY users_id DESC");
		?>
		<div class="panel panel-black br-radius-zero">
		  <div class="panel-heading">Chat With Users</div>
		  <div class="panel-body" style="height: 250px; overflow: auto; text-transform: capitalize;">
		  	<?php
			
			foreach ($fetchcp as $rows) {
				try {

					$user=$rows['username'];
					echo "<b id='".$user."' value='".$user."'>".$rows['username']."<em style='color: #008000;'><i class='fa fa-user pull-right'></i></em></b><hr>";
					echo "<script>
						$(document).ready(function(){
							$('#".$user."').hover(function(){
	    					$(this).css('cursor','pointer');
		    				});
		    				$('#".$user."').click(function () {												
		    					$('.chatbox').show(500);
		    					$('.auser').text('".$user."');

		    					  var profile = $(this).attr('value');
		    					  $.get('includes/messageajax.php',{profile:profile});
		    					  $.get('includes/readmessagequery.php',{profile:profile});
					              $.get('includes/sendmessagequery.php',{profile:profile});
							});
							$('.closechat').hover(function(){
	    					$(this).css('cursor','pointer');
		    				});
							$('.closechat').click(function(){
		    					$('.chatbox').hide(500);
		    				});
						});
					</script>";
					include 'includes/bulkmessages.php';
					
				} catch (Exception $e) {
					$e->getMessage();
				}
			}

			?>
		  </div>
		</div>	

		<?php
	}

	public function UnreadmessagesQuery($username)
	{
		$sqlrcn=$this->icon->query("SELECT DISTINCT sender FROM chat_tb WHERE receiver='$username' AND status='Unread'");
		$i=1;
		foreach ($sqlrcn as $not) {
		  $sender=$not['sender'];

		?>
		<div>
		  <b id="<?php echo $sender; ?>" value="<?php echo $sender; ?>"><?php echo $sender; ?></b><i class="pull-right" style="color:red;">
		   <?php
		   echo "<script>
					//Click
					$(document).ready(function () {
						$('#".$sender."').hover(function(){
							$(this).css('cursor','pointer');
						});
						$('#".$sender."').click(function () {												
							$('.chatbox').show(500);
							$('.auser').text('".$sender."');
							
		          var profile = $(this).attr('value');
		          $.get('includes/messageajax.php',{profile:profile});
		          $.get('includes/readmessagequery.php',{profile:profile});
		          $.get('includes/sendmessagequery.php',{profile:profile});
						});
						$('.closechat').click(function(){
							$('.chatbox').hide(500);
						});
					});
				 </script>";    
		   $sqlur=$this->icon->query("SELECT * FROM chat_tb WHERE receiver='$username' AND sender='$sender' AND status='Unread'");            
		     $numur=$sqlur->num_rows;
		    if ($numur==0) {
		    }
		    else{
		    echo '<big class="badge" style="color:#FF4500; background:#FFFFFF;">'.$numur.'</big>';
		    }

		   ?>		     
		   </i>
		  </b><hr>
		</div>

		<?php
		$i++;
		}
	}

	public function SendMessageQuery($sender,$receiver,$messagebody)
	{

        $send=$this->icon->query("INSERT INTO chat_tb SET sender='$sender',receiver='$receiver',messagebody='$messagebody',timesent=now(),status='Unread'");  
 		try {
 			 if ($send) {
	        	return true;
	        }
	        else{
	        	return false;
	        }
 		} catch (Exception $e) {
 			$e->getMessage();
 		}
	       
	}	

	public function FetchMessagesQuery($username,$profile)
	{

          $qry=$this->icon->query("SELECT * FROM chat_tb WHERE (receiver='$username' AND sender='$profile') OR (receiver='$profile' AND sender='$username') ORDER BY chat_id DESC");
          foreach ($qry as $roww) {
            
            $chat_id=$roww['chat_id'];
           if ($roww['receiver']===@$username) { 
          ?>
            <div align="left">
                <span class="periodel"> 
                <?php
                echo $roww['timesent'];
                ?>
                </span>
                <div class="messagel">
                <?php
                echo $roww['messagebody'];	                        
                ?>          
                </div>
            </div>
        <?php
		}
		if($roww['receiver']===@$profile){
          
          ?>
            <div align="right">            
                <span class="perioder">  
                <?php
                echo $roww['timesent'];
                ?>
                </span> 
                <div class="messager">
              	<?php
              	   $rdm=$this->icon->query("SELECT * FROM chat_tb WHERE sender='$username' AND receiver='$profile' AND chat_id='$chat_id' AND status='Read'");
              	   $gt=$rdm->num_rows;
                   echo $roww['messagebody']."&nbsp<em style='font-size: 8px;'><i class='fa fa-check'></i>";
                   if ($gt===1) {
                   	echo "<i class='fa fa-check'></i>";
                   }
                   echo"</em>";
                   $app=$this->icon->query("SELECT * FROM chat_tb WHERE sender='$username' AND receiver='$profile' AND chat_id='$chat_id'");
                   $che=$app->num_rows;
                ?>            
                </div>

            </div>
        	  <?php
              	}
              }

         
	}

	
	public function MessagenotificationQuery($username)
	{
		$sqlrc=$this->icon->query("SELECT * FROM chat_tb WHERE receiver='$username' AND status='Unread'");
		$numrc=$sqlrc->num_rows;
		if ($numrc==0) {

		}
		else{
		echo '<big class="badge" style="background-color:#FFFFFF; color:#FF0000;">'.$numrc.'</big>';
		}
	}

	public function ReadmessageQuery($username,$profile)
	{
		$red=$this->icon->query("UPDATE chat_tb SET status='Read' WHERE receiver='$username' AND sender='$profile'");
	}

	public function ClearlogspQuery()
	{
		$learlogs=$this->icon->query("DELETE FROM capture_tb");
		try {
			if ($learlogs) {
					echo "<script>alert('Process Complete !')</script>";
					echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
				}
				else{
					echo "<script>alert('Process Incomplete !')</script>";
					echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
				}
		} catch (Exception $e) {
			$e->getMessage();
		}
	}

	public function AddusersQuery($names,$username,$password,$email,$telephone,$gender)
	{
		$password=sha1(md5($password));
		$chu=$this->icon->query("SELECT * FROM users_tb SET WHERE username='$username' AND email='$email'");
		$num=$chu->num_rows;
		if ($num==1) {
			echo "<script>alert('".$username." already exists !')</script>";
			echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
		}
		else{
			$addu=$this->icon->query("INSERT INTO users_tb SET names='$names',username='$username',password='$password',email='$email',telephone='$telephone',gender='$gender',permission='User',access='No' ");
			try {
				if ($addu) {
					echo "<script>alert('".$username." has been added !')</script>";
					echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
				}
				else{
					echo "<script>alert('Error occured while adding ".$username." !')</script>";
					echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
				}
			} catch (Exception $e) {
				$e->getMessage();
			}
		}
		
	}

	
	public function FetchUsers()
	{
		$ftusers=$this->icon->query("SELECT * FROM users_tb ORDER BY users_id DESC");
		?>
		<div style="height: 500px; overflow: auto; text-transform: capitalize;">
			<table class="table table-striped table-bordered table-responsive table-hover small">
				<tr>
					<th>Names</th>
					<th>Gender</th>
					<th>Username</th>
					<th>Telephone</th>
					<th>Email Address</th>
					<th>Edit / Del</th>
				</tr>
			
			<?php
			foreach($ftusers as $row) {
				$users_id=$row['users_id'];
				echo "<tr>";
				echo "<td>".$row['names']."</td>";
				echo "<td>".$row['gender']."</td>";
				echo "<td>".$row['username']."</td>";
				echo "<td>".$row['telephone']."</td>";
				echo "<td style='text-transform: lowercase;'>".$row['email']."</td>";
				$thisuser=$this->icon->query("SELECT * FROM users_tb WHERE users_id='$users_id' AND access='No' ");
				$true=$thisuser->num_rows;
				echo "<td style='padding-right: 0px;' margin-right: 0px;>
						<a href='#edituser".$users_id."' class='btn btn-xs btn-primary' data-toggle='modal'><i class='fa fa-edit'>&nbsp</i></a>";
						if ($true==1) {
							echo "<a href='includes/gaccess.php?users_id=".$users_id."' class='btn btn-xs btn-success' onclick='return Comfirm();')><i class='fa fa-check-circle-o'>&nbsp</i>Unlock</a>";
						}
						else{
							echo "<a href='includes/daccess.php?users_id=".$users_id."' class='btn btn-xs btn-warning' onclick='return Comfirm();')><i class='fa fa-ban'>&nbsp</i>Lock</a>";
						}
						echo "<a href='includes/deleteuser.php?users_id=".$users_id."' class='btn btn-xs btn-danger' onclick='return Comfirm();')><i class='fa fa-trash-o'>&nbsp</i></a>

						</td>";
				echo "</tr>";
				include 'includes/edituser.php';
				
			}
			?>
			</table>
		</div>
		<?php		
		
	}

	public function UsersnumQuery()
	{
		$usersnum=$this->icon->query("SELECT * FROM users_tb");
		echo $un=$usersnum->num_rows;
	}

	public function ProffessionalsnumQuery()
	{
		$usersnum=$this->icon->query("SELECT * FROM employees_tb WHERE role IN('HR','Accountant','Auditor','Administrative','Engneer','It','Medicalworker','Finacialmanager','Executivemanager','Legalrepresentative')");
		echo $un=$usersnum->num_rows;
	}

	public function SemiproffessionalsnumQuery()
	{
		$usersnum=$this->icon->query("SELECT * FROM employees_tb WHERE role IN('Painters','Receptionists','Drivers','Securityguards','Dataenteries','Secriteries','Officeassistants','Salespersonel','Storemanagers','Cateringservices','Tourguides')");
		echo $un=$usersnum->num_rows;
	}

	public function CasualworkersnumQuery()
	{
		$usersnum=$this->icon->query("SELECT * FROM employees_tb WHERE role IN('Domestichelpers','Cleaners','Operationalworkers','Others')");
		echo $un=$usersnum->num_rows;
	}

	public function HrnumQuery()
	{
		$hrnum=$this->icon->query("SELECT * FROM employees_tb WHERE role='HR'");
		echo $un=$hrnum->num_rows;
	}

	public function AccountantnumQuery()
	{
		$hrnum=$this->icon->query("SELECT * FROM employees_tb WHERE role='Accountant'");
		echo $un=$hrnum->num_rows;
	}

	public function AuditornumQuery()
	{
		$hrnum=$this->icon->query("SELECT * FROM employees_tb WHERE role='Auditor'");
		echo $un=$hrnum->num_rows;
	}

	public function AdministratornumQuery()
	{
		$hrnum=$this->icon->query("SELECT * FROM employees_tb WHERE role='Administrator'");
		echo $un=$hrnum->num_rows;
	}

	public function EngineernumQuery()
	{
		$hrnum=$this->icon->query("SELECT * FROM employees_tb WHERE role='Engineer'");
		echo $un=$hrnum->num_rows;
	}

	public function ItnumQuery()
	{
		$hrnum=$this->icon->query("SELECT * FROM employees_tb WHERE role='It'");
		echo $un=$hrnum->num_rows;
	}

	public function MedicalworkernumQuery()
	{
		$hrnum=$this->icon->query("SELECT * FROM employees_tb WHERE role='Medicalworker'");
		echo $un=$hrnum->num_rows;
	}

	public function FinacialmanagernumQuery()
	{
		$hrnum=$this->icon->query("SELECT * FROM employees_tb WHERE role='Finacialmanager'");
		echo $un=$hrnum->num_rows;
	}

	public function ExecutivemanagernumQuery()
	{
		$hrnum=$this->icon->query("SELECT * FROM employees_tb WHERE role='Executivemanager'");
		echo $un=$hrnum->num_rows;
	}

	public function LegalrepresentativenumQuery()
	{
		$hrnum=$this->icon->query("SELECT * FROM employees_tb WHERE role='Legalrepresentative'");
		echo $un=$hrnum->num_rows;
	}

	public function MarketingmanagernumQuery()
	{
		$hrnum=$this->icon->query("SELECT * FROM employees_tb WHERE role='Marketingmanager'");
		echo $un=$hrnum->num_rows;
	}

	public function TeachersnumQuery()
	{
		$hrnum=$this->icon->query("SELECT * FROM employees_tb WHERE role='Teachers'");
		echo $un=$hrnum->num_rows;
	}

	public function PaintersnumQuery()
	{
		$hrnum=$this->icon->query("SELECT * FROM employees_tb WHERE role='Painters'");
		echo $un=$hrnum->num_rows;
	}

	public function ReceptionistsnumQuery()
	{
		$hrnum=$this->icon->query("SELECT * FROM employees_tb WHERE role='Receptionists'");
		echo $un=$hrnum->num_rows;
	}

	public function DriversnumQuery()
	{
		$hrnum=$this->icon->query("SELECT * FROM employees_tb WHERE role='Drivers'");
		echo $un=$hrnum->num_rows;
	}

	public function SecurityguardsnumQuery()
	{
		$hrnum=$this->icon->query("SELECT * FROM employees_tb WHERE role='Securityguards'");
		echo $un=$hrnum->num_rows;
	}

	public function DataenteriesnumQuery()
	{
		$hrnum=$this->icon->query("SELECT * FROM employees_tb WHERE role='Dataenteries'");
		echo $un=$hrnum->num_rows;
	}

	public function SecriteriesnumQuery()
	{
		$hrnum=$this->icon->query("SELECT * FROM employees_tb WHERE role='Secriteries'");
		echo $un=$hrnum->num_rows;
	}

	public function OfficeassistantsnumQuery()
	{
		$hrnum=$this->icon->query("SELECT * FROM employees_tb WHERE role='Officeassistants'");
		echo $un=$hrnum->num_rows;
	}

	public function SalespersonelnumQuery()
	{
		$hrnum=$this->icon->query("SELECT * FROM employees_tb WHERE role='Salespersonel'");
		echo $un=$hrnum->num_rows;
	}

	public function StoremanagersnumQuery()
	{
		$hrnum=$this->icon->query("SELECT * FROM employees_tb WHERE role='Storemanagers'");
		echo $un=$hrnum->num_rows;
	}

	public function CateringservicesnumQuery()
	{
		$hrnum=$this->icon->query("SELECT * FROM employees_tb WHERE role='Cateringservices'");
		echo $un=$hrnum->num_rows;
	}

	public function TourguidesnumQuery()
	{
		$hrnum=$this->icon->query("SELECT * FROM employees_tb WHERE role='Tourguides'");
		echo $un=$hrnum->num_rows;
	}

	public function AspothersnumQuery()
	{
		$hrnum=$this->icon->query("SELECT * FROM employees_tb WHERE role='Aspothers'");
		echo $un=$hrnum->num_rows;
	}

	public function DomestichelpersnumQuery()
	{
		$hrnum=$this->icon->query("SELECT * FROM employees_tb WHERE role='Domestichelpers'");
		echo $un=$hrnum->num_rows;
	}

	public function CleanersnumQuery()
	{
		$hrnum=$this->icon->query("SELECT * FROM employees_tb WHERE role='Cleaners'");
		echo $un=$hrnum->num_rows;
	}

	public function OperationalworkersnumQuery()
	{
		$hrnum=$this->icon->query("SELECT * FROM employees_tb WHERE role='Operationalworkers'");
		echo $un=$hrnum->num_rows;
	}

	public function OthersnumQuery()
	{
		$hrnum=$this->icon->query("SELECT * FROM employees_tb WHERE role='Others'");
		echo $un=$hrnum->num_rows;
	}

	public function AcpasswordQuery($username,$oldpassword,$newpassword)
	{
		$chs=$this->icon->query("SELECT * FROM admin_tb WHERE username='$username'");
		$rq=$chs->fetch_array();

		if (strlen($oldpassword)<5) {
			echo "<script>alert('Dear ".$username. "Password length should be five characters and above')</script>";
			echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
		}
		else if (strlen($newpassword)<5) {
			echo "<script>alert('Dear ".$username. "New password length should be five characters and above')</script>";
			echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
		}
		else if (strlen($oldpassword)>5 && strlen($newpassword)>5 && $rq['password']!=sha1(md5($oldpassword))) {
			echo "<script>alert('Old password is wrong because there is no  match found in our database')</script>";
			echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
		}
		else{                   
			$password=sha1(md5($newpassword));
			$qu=$this->icon->query("UPDATE admin_tb SET password='$password' WHERE username='$username'");
			if ($qu) {
			echo "<script>alert('Password chaged successfully ".$username .".')</script>";
			echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
			}
			else{
			echo "<script>alert('Error......')</script>";
			echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
			}
		} 
	}

	public function EditusersQuery($users_id,$names,$username,$email,$telephone,$gender)
	{

		$editu=$this->icon->query("UPDATE users_tb SET names='$names',username='$username',email='$email',telephone='$telephone',gender='$gender',permission='User' WHERE users_id='$users_id'");
			try {
				if ($editu) {
					echo "<script>alert('Process successful !')</script>";
					echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
				}
				else{
					echo "<script>alert('Error !')</script>";
					echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
				}
			} catch (Exception $e) {
				$e->getMessage();
			}
		
	}

	public function DeleteusserQuery($users_id)
	{
		$deluser=$this->icon->query("DELETE FROM users_tb WHERE users_id='$users_id'");
		try {
			if ($deluser) {
				echo "<script>alert('Deleting done !')</script>";
				echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
			}
			else{
				echo "<script>alert('Error occured while deleting')</script>";
				echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
			}
		} catch (Exception $e) {
			$e->getMessage();
		}
	}

	public function GrantaccessQuery($users_id)
	{
		$gaccess=$this->icon->query("UPDATE users_tb SET access='Yes' WHERE users_id='$users_id'");
		try {
			if ($gaccess) {
				echo "<script>alert('Access Granted !')</script>";
				echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
			}
			else{
				echo "<script>alert('Error !')</script>";
				echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
			}
		} catch (Exception $e) {
			$e->getMessage();
		}
	}

	public function DenyaccessQuery($users_id)
	{
		$gaccess=$this->icon->query("UPDATE users_tb SET access='No' WHERE users_id='$users_id'");
		try {
			if ($gaccess) {
				echo "<script>alert('Access Denyed !')</script>";
				echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
			}
			else{
				echo "<script>alert('Error !')</script>";
				echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
			}
		} catch (Exception $e) {
			$e->getMessage();
		}
	}

	public function AddhrQuery($names,$gender,$qualification,$experience,$specialisation,$category,$telephone,$document)
	{
		$chex=$this->icon->query("SELECT * FROM employees_tb SET WHERE telephone='$telephone'");
		$num=$chex->num_rows;
		if ($num==1) {
			echo "<script>alert('Employee already exists !')</script>";
			echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
		}
		else{
			$tempname=$_FILES['document']['tmp_name'];
	        $orignalname=$_FILES['document']['name'];
	        $size=($_FILES['document']['size']/5242880)."MB <br>";
	        $type=$_FILES['document']['type'];
	        $document=$_FILES['document']['name'];
	        move_uploaded_file($_FILES['document']['tmp_name'],"docs/documents/".$_FILES["document"]["name"]);
			$addhr=$this->icon->query("INSERT INTO employees_tb SET names='$names',gender='$gender',role='HR',qualification='$qualification',experience='$experience',specialisation='$specialisation',category='$category',telephone='$telephone',document='$document',status='".date("d/m/Y")."' ");
			try {
				if ($addhr) {
					echo "<script>alert('HR has been added !')</script>";
					echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
				}
				else{
					echo "<script>alert('Error occured while adding HR !')</script>";
					echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
				}
			} catch (Exception $e) {
				$e->getMessage();
			}
		}
		
	}

	public function FetchHr()
	{
		$fthr=$this->icon->query("SELECT * FROM employees_tb WHERE role='HR' ORDER BY employee_id DESC");
		?>
		<div style="height: 500px; overflow: auto; text-transform: capitalize;" id="hr">
			<table class="table table-striped table-bordered table-responsive table-hover small">
				<tr>
					<th>Names</th>
					<th>Gender</th>
					<th>Qualifications</th>
					<th>Experience</th>
					<th>Specialisation</th>
					<th>Category</th>
					<th>Contact</th>
					<th>Documents</th>
					<th>Edit / Del</th>
				</tr>
			
			<?php
			foreach($fthr as $row) {
				$employee_id=$row['employee_id'];
				$document=$row['document'];
				echo "<tr>";
				echo "<td>".$row['names']."</td>";
				echo "<td>".$row['gender'];
				if ($row['status']==date("d/m/Y")) {
					echo "&nbsp<i style='font-size: 11px; background-color: #ff0000; color:#fff; padding: 1px;'>new</i>";
				}
				echo "</td>";
				echo "<td>".$row['qualification']."</td>";
				echo "<td>".$row['experience']."</td>";				
				echo "<td>".$row['specialisation']."</td>";
				echo "<td>".$row['category']."</td>";
				echo "<td>".$row['telephone']."</td>";
				echo "<td><a href='includes/downloaddocument.php?download=".$document."' class='btn btn-xs btn-success br-radius-zero'><i class='fa fa-download'>&nbsp</i>Downoad</a></td>";
				echo "<td style='padding-right: 0px;' margin-right: 0px;>
						<a href='#editemp".$employee_id."' class='btn btn-xs btn-primary' data-toggle='modal'><i class='fa fa-edit'>&nbsp</i></a>
						<a href='includes/deleteemp.php?employee_id=".$employee_id."' class='btn btn-xs btn-danger' onclick='return Comfirm();')><i class='fa fa-trash-o'>&nbsp</i></a>

						</td>";
				echo "</tr>";
				include 'includes/editemp.php';
			}
			?>
			</table>
		</div>
		<?php	
		
	}
	

	public function EditEmpQuery($employee_id,$names,$gender,$qualification,$experience,$specialisation,$category,$telephone,$status)
	{
		$tempname=$_FILES['document']['tmp_name'];
        $orignalname=$_FILES['document']['name'];
        $size=($_FILES['document']['size']/5242880)."MB <br>";
        $type=$_FILES['document']['type'];
        $document=$_FILES['document']['name'];
        move_uploaded_file($_FILES['document']['tmp_name'],"docs/documents/".$_FILES["document"]["name"]);
		$edemp=$this->icon->query("UPDATE employees_tb SET names='$names',gender='$gender',qualification='$qualification',experience='$experience',specialisation='$specialisation',category='$category',telephone='$telephone',document='$document',status='".date("d/m/Y")."',status='$status' WHERE employee_id='$employee_id' ");
		try {
			if ($edemp) {
				echo "<script>alert('Editing Complete !')</script>";
				echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
			}
			else{
				echo "<script>alert('Error !')</script>";
				echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
			}
		} catch (Exception $e) {
			$e->getMessage();
		}
		
	}

	public function DeleteEmpQuery($employee_id)
	{
		$delemp=$this->icon->query("DELETE FROM employees_tb WHERE employee_id='$employee_id'");
		try {
			if ($delemp) {
				echo "<script>alert('Deleting done !')</script>";
				echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
			}
			else{
				echo "<script>alert('Error occured while deleting')</script>";
				echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
			}
		} catch (Exception $e) {
			$e->getMessage();
		}
	}

	public function AddAccountantQuery($names,$gender,$qualification,$experience,$specialisation,$category,$telephone,$document)
	{
		$chex=$this->icon->query("SELECT * FROM employees_tb SET WHERE telephone='$telephone'");
		$num=$chex->num_rows;
		if ($num==1) {
			echo "<script>alert('Employee already exists !')</script>";
			echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
		}
		else{
			$tempname=$_FILES['document']['tmp_name'];
	        $orignalname=$_FILES['document']['name'];
	        $size=($_FILES['document']['size']/5242880)."MB <br>";
	        $type=$_FILES['document']['type'];
	        $document=$_FILES['document']['name'];
	        move_uploaded_file($_FILES['document']['tmp_name'],"docs/documents/".$_FILES["document"]["name"]);
			$addhr=$this->icon->query("INSERT INTO employees_tb SET names='$names',gender='$gender',role='Accountant',qualification='$qualification',experience='$experience',specialisation='$specialisation',category='$category',telephone='$telephone',document='$document',status='".date("d/m/Y")."' ");
			try {
				if ($addhr) {
					echo "<script>alert('Accountant has been added !')</script>";
					echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
				}
				else{
					echo "<script>alert('Error occured while adding Accountant !')</script>";
					echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
				}
			} catch (Exception $e) {
				$e->getMessage();
			}
		}
		
	}

	public function FetchAccountants()
	{
		$fthr=$this->icon->query("SELECT * FROM employees_tb WHERE role='Accountant' ORDER BY employee_id DESC");
		?>
		<div style="height: 500px; overflow: auto; text-transform: capitalize;">
			<table class="table table-striped table-bordered table-responsive table-hover small">
				<tr>
					<th>Names</th>
					<th>Gender</th>
					<th>Qualifications</th>
					<th>Experience</th>
					<th>Specialisation</th>
					<th>Category</th>
					<th>Contact</th>
					<th>Documents</th>
					<th>Edit / Del</th>
				</tr>
			
			<?php
			foreach($fthr as $row) {
				$employee_id=$row['employee_id'];
				$document=$row['document'];
				echo "<tr>";
				echo "<td>".$row['names']."</td>";
				echo "<td>".$row['gender'];
				if ($row['status']==date("d/m/Y")) {
					echo "&nbsp<i style='font-size: 11px; background-color: #ff0000; color:#fff; padding: 1px;'>new</i>";
				}
				echo "</td>";
				echo "<td>".$row['qualification']."</td>";
				echo "<td>".$row['experience']."</td>";				
				echo "<td>".$row['specialisation']."</td>";
				echo "<td>".$row['category']."</td>";
				echo "<td>".$row['telephone']."</td>";
				echo "<td><a href='includes/downloaddocument.php?download=".$document."' class='btn btn-xs btn-success br-radius-zero'><i class='fa fa-download'>&nbsp</i>Downoad</a></td>";
				echo "<td style='padding-right: 0px;' margin-right: 0px;>
						<a href='#editemp".$employee_id."' class='btn btn-xs btn-primary' data-toggle='modal'><i class='fa fa-edit'>&nbsp</i></a>
						<a href='includes/deleteemp.php?employee_id=".$employee_id."' class='btn btn-xs btn-danger' onclick='return Comfirm();')><i class='fa fa-trash-o'>&nbsp</i></a>

						</td>";
				echo "</tr>";
				include 'includes/editemp.php';
			}
			?>
			</table>
		</div>
		<?php	
		
	}

	public function AddAuditorQuery($names,$gender,$qualification,$experience,$specialisation,$category,$telephone,$document)
	{
		$chex=$this->icon->query("SELECT * FROM employees_tb SET WHERE telephone='$telephone'");
		$num=$chex->num_rows;
		if ($num==1) {
			echo "<script>alert('Employee already exists !')</script>";
			echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
		}
		else{
			$tempname=$_FILES['document']['tmp_name'];
	        $orignalname=$_FILES['document']['name'];
	        $size=($_FILES['document']['size']/5242880)."MB <br>";
	        $type=$_FILES['document']['type'];
	        $document=$_FILES['document']['name'];
	        move_uploaded_file($_FILES['document']['tmp_name'],"docs/documents/".$_FILES["document"]["name"]);
			$addhr=$this->icon->query("INSERT INTO employees_tb SET names='$names',gender='$gender',role='Auditor',qualification='$qualification',experience='$experience',specialisation='$specialisation',category='$category',telephone='$telephone',document='$document',status='".date("d/m/Y")."' ");
			try {
				if ($addhr) {
					echo "<script>alert('Auditor has been added !')</script>";
					echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
				}
				else{
					echo "<script>alert('Error occured while adding Auditor !')</script>";
					echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
				}
			} catch (Exception $e) {
				$e->getMessage();
			}
		}
		
	}

	public function FetchAuditor()
	{
		$fthr=$this->icon->query("SELECT * FROM employees_tb WHERE role='Auditor' ORDER BY employee_id DESC");
		?>
		<div style="height: 500px; overflow: auto; text-transform: capitalize;">
			<table class="table table-striped table-bordered table-responsive table-hover small">
				<tr>
					<th>Names</th>
					<th>Gender</th>
					<th>Qualifications</th>
					<th>Experience</th>
					<th>Specialisation</th>
					<th>Category</th>
					<th>Contact</th>
					<th>Documents</th>
					<th>Edit / Del</th>
				</tr>
			
			<?php
			foreach($fthr as $row) {
				$employee_id=$row['employee_id'];
				$document=$row['document'];
				echo "<tr>";
				echo "<td>".$row['names']."</td>";
				echo "<td>".$row['gender'];
				if ($row['status']==date("d/m/Y")) {
					echo "&nbsp<i style='font-size: 11px; background-color: #ff0000; color:#fff; padding: 1px;'>new</i>";
				}
				echo "</td>";
				echo "<td>".$row['qualification']."</td>";
				echo "<td>".$row['experience']."</td>";				
				echo "<td>".$row['specialisation']."</td>";
				echo "<td>".$row['category']."</td>";
				echo "<td>".$row['telephone']."</td>";
				echo "<td><a href='includes/downloaddocument.php?download=".$document."' class='btn btn-xs btn-success br-radius-zero'><i class='fa fa-download'>&nbsp</i>Downoad</a></td>";
				echo "<td style='padding-right: 0px;' margin-right: 0px;>
						<a href='#editemp".$employee_id."' class='btn btn-xs btn-primary' data-toggle='modal'><i class='fa fa-edit'>&nbsp</i></a>
						<a href='includes/deleteemp.php?employee_id=".$employee_id."' class='btn btn-xs btn-danger' onclick='return Comfirm();')><i class='fa fa-trash-o'>&nbsp</i></a>

						</td>";
				echo "</tr>";
				include 'includes/editemp.php';
			}
			?>
			</table>
		</div>
		<?php	
		
	}

	public function AddAdministratorQuery($names,$gender,$qualification,$experience,$specialisation,$category,$telephone,$document)
	{
		$chex=$this->icon->query("SELECT * FROM employees_tb SET WHERE telephone='$telephone'");
		$num=$chex->num_rows;
		if ($num==1) {
			echo "<script>alert('Employee already exists !')</script>";
			echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
		}
		else{
			$tempname=$_FILES['document']['tmp_name'];
	        $orignalname=$_FILES['document']['name'];
	        $size=($_FILES['document']['size']/5242880)."MB <br>";
	        $type=$_FILES['document']['type'];
	        $document=$_FILES['document']['name'];
	        move_uploaded_file($_FILES['document']['tmp_name'],"docs/documents/".$_FILES["document"]["name"]);
			$addhr=$this->icon->query("INSERT INTO employees_tb SET names='$names',gender='$gender',role='Administrator',qualification='$qualification',experience='$experience',specialisation='$specialisation',category='$category',telephone='$telephone',document='$document',status='".date("d/m/Y")."' ");
			try {
				if ($addhr) {
					echo "<script>alert('Administrative has been added !')</script>";
					echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
				}
				else{
					echo "<script>alert('Error occured while adding Administrative !')</script>";
					echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
				}
			} catch (Exception $e) {
				$e->getMessage();
			}
		}
		
	}

	public function FetchAdministrator()
	{
		$fthr=$this->icon->query("SELECT * FROM employees_tb WHERE role='Administrator' ORDER BY employee_id DESC");
		?>
		<div style="height: 500px; overflow: auto; text-transform: capitalize;">
			<table class="table table-striped table-bordered table-responsive table-hover small">
				<tr>
					<th>Names</th>
					<th>Gender</th>
					<th>Qualifications</th>
					<th>Experience</th>
					<th>Specialisation</th>
					<th>Category</th>
					<th>Contact</th>
					<th>Documents</th>
					<th>Edit / Del</th>
				</tr>
			
			<?php
			foreach($fthr as $row) {
				$employee_id=$row['employee_id'];
				$document=$row['document'];
				echo "<tr>";
				echo "<td>".$row['names']."</td>";
				echo "<td>".$row['gender'];
				if ($row['status']==date("d/m/Y")) {
					echo "&nbsp<i style='font-size: 11px; background-color: #ff0000; color:#fff; padding: 1px;'>new</i>";
				}
				echo "</td>";
				echo "<td>".$row['qualification']."</td>";
				echo "<td>".$row['experience']."</td>";				
				echo "<td>".$row['specialisation']."</td>";
				echo "<td>".$row['category']."</td>";
				echo "<td>".$row['telephone']."</td>";
				echo "<td><a href='includes/downloaddocument.php?download=".$document."' class='btn btn-xs btn-success br-radius-zero'><i class='fa fa-download'>&nbsp</i>Downoad</a></td>";
				echo "<td style='padding-right: 0px;' margin-right: 0px;>
						<a href='#editemp".$employee_id."' class='btn btn-xs btn-primary' data-toggle='modal'><i class='fa fa-edit'>&nbsp</i></a>
						<a href='includes/deleteemp.php?employee_id=".$employee_id."' class='btn btn-xs btn-danger' onclick='return Comfirm();')><i class='fa fa-trash-o'>&nbsp</i></a>

						</td>";
				echo "</tr>";
				include 'includes/editemp.php';
			}
			?>
			</table>
		</div>
		<?php	
		
	}

	public function AddEngineerQuery($names,$gender,$qualification,$experience,$specialisation,$category,$telephone,$document)
	{
		$chex=$this->icon->query("SELECT * FROM employees_tb SET WHERE telephone='$telephone'");
		$num=$chex->num_rows;
		if ($num==1) {
			echo "<script>alert('Employee already exists !')</script>";
			echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
		}
		else{
			$tempname=$_FILES['document']['tmp_name'];
	        $orignalname=$_FILES['document']['name'];
	        $size=($_FILES['document']['size']/5242880)."MB <br>";
	        $type=$_FILES['document']['type'];
	        $document=$_FILES['document']['name'];
	        move_uploaded_file($_FILES['document']['tmp_name'],"docs/documents/".$_FILES["document"]["name"]);
			$addhr=$this->icon->query("INSERT INTO employees_tb SET names='$names',gender='$gender',role='Engineer',qualification='$qualification',experience='$experience',specialisation='$specialisation',category='$category',telephone='$telephone',document='$document',status='".date("d/m/Y")."' ");
			try {
				if ($addhr) {
					echo "<script>alert('Engneer has been added !')</script>";
					echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
				}
				else{
					echo "<script>alert('Error occured while adding Engneer !')</script>";
					echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
				}
			} catch (Exception $e) {
				$e->getMessage();
			}
		}
		
	}

	public function FetchEngineer()
	{
		$fthr=$this->icon->query("SELECT * FROM employees_tb WHERE role='Engineer' ORDER BY employee_id DESC");
		?>
		<div style="height: 500px; overflow: auto; text-transform: capitalize;">
			<table class="table table-striped table-bordered table-responsive table-hover small">
				<tr>
					<th>Names</th>
					<th>Gender</th>
					<th>Qualifications</th>
					<th>Experience</th>
					<th>Specialisation</th>
					<th>Category</th>
					<th>Contact</th>
					<th>Documents</th>
					<th>Edit / Del</th>
				</tr>
			
			<?php
			foreach($fthr as $row) {
				$employee_id=$row['employee_id'];
				$document=$row['document'];
				echo "<tr>";
				echo "<td>".$row['names']."</td>";
				echo "<td>".$row['gender'];
				if ($row['status']==date("d/m/Y")) {
					echo "&nbsp<i style='font-size: 11px; background-color: #ff0000; color:#fff; padding: 1px;'>new</i>";
				}
				echo "</td>";
				echo "<td>".$row['qualification']."</td>";
				echo "<td>".$row['experience']."</td>";				
				echo "<td>".$row['specialisation']."</td>";
				echo "<td>".$row['category']."</td>";
				echo "<td>".$row['telephone']."</td>";
				echo "<td><a href='includes/downloaddocument.php?download=".$document."' class='btn btn-xs btn-success br-radius-zero'><i class='fa fa-download'>&nbsp</i>Downoad</a></td>";
				echo "<td style='padding-right: 0px;' margin-right: 0px;>
						<a href='#editemp".$employee_id."' class='btn btn-xs btn-primary' data-toggle='modal'><i class='fa fa-edit'>&nbsp</i></a>
						<a href='includes/deleteemp.php?employee_id=".$employee_id."' class='btn btn-xs btn-danger' onclick='return Comfirm();')><i class='fa fa-trash-o'>&nbsp</i></a>

						</td>";
				echo "</tr>";
				include 'includes/editemp.php';
			}
			?>
			</table>
		</div>
		<?php	
		
	}

	public function AddItQuery($names,$gender,$qualification,$experience,$specialisation,$category,$telephone,$document)
	{
		$chex=$this->icon->query("SELECT * FROM employees_tb SET WHERE telephone='$telephone'");
		$num=$chex->num_rows;
		if ($num==1) {
			echo "<script>alert('Employee already exists !')</script>";
			echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
		}
		else{
			$tempname=$_FILES['document']['tmp_name'];
	        $orignalname=$_FILES['document']['name'];
	        $size=($_FILES['document']['size']/5242880)."MB <br>";
	        $type=$_FILES['document']['type'];
	        $document=$_FILES['document']['name'];
	        move_uploaded_file($_FILES['document']['tmp_name'],"docs/documents/".$_FILES["document"]["name"]);
			$addhr=$this->icon->query("INSERT INTO employees_tb SET names='$names',gender='$gender',role='It',qualification='$qualification',experience='$experience',specialisation='$specialisation',category='$category',telephone='$telephone',document='$document',status='".date("d/m/Y")."' ");
			try {
				if ($addhr) {
					echo "<script>alert('It has been added !')</script>";
					echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
				}
				else{
					echo "<script>alert('Error occured while adding It !')</script>";
					echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
				}
			} catch (Exception $e) {
				$e->getMessage();
			}
		}
		
	}
	public function FetchIt()
	{
		$fthr=$this->icon->query("SELECT * FROM employees_tb WHERE role='It' ORDER BY employee_id DESC");
		?>
		<div style="height: 500px; overflow: auto; text-transform: capitalize;">
			<table class="table table-striped table-bordered table-responsive table-hover small">
				<tr>
					<th>Names</th>
					<th>Gender</th>
					<th>Qualifications</th>
					<th>Experience</th>
					<th>Specialisation</th>
					<th>Category</th>
					<th>Contact</th>
					<th>Documents</th>
					<th>Edit / Del</th>
				</tr>
			
			<?php
			foreach($fthr as $row) {
				$employee_id=$row['employee_id'];
				$document=$row['document'];
				echo "<tr>";
				echo "<td>".$row['names']."</td>";
				echo "<td>".$row['gender'];
				if ($row['status']==date("d/m/Y")) {
					echo "&nbsp<i style='font-size: 11px; background-color: #ff0000; color:#fff; padding: 1px;'>new</i>";
				}
				echo "</td>";
				echo "<td>".$row['qualification']."</td>";
				echo "<td>".$row['experience']."</td>";				
				echo "<td>".$row['specialisation']."</td>";
				echo "<td>".$row['category']."</td>";
				echo "<td>".$row['telephone']."</td>";
				echo "<td><a href='includes/downloaddocument.php?download=".$document."' class='btn btn-xs btn-success br-radius-zero'><i class='fa fa-download'>&nbsp</i>Downoad</a></td>";
				echo "<td style='padding-right: 0px;' margin-right: 0px;>
						<a href='#editemp".$employee_id."' class='btn btn-xs btn-primary' data-toggle='modal'><i class='fa fa-edit'>&nbsp</i></a>
						<a href='includes/deleteemp.php?employee_id=".$employee_id."' class='btn btn-xs btn-danger' onclick='return Comfirm();')><i class='fa fa-trash-o'>&nbsp</i></a>

						</td>";
				echo "</tr>";
				include 'includes/editemp.php';
			}
			?>
			</table>
		</div>
		<?php	
		
	}

	public function AddMedicalworkerQuery($names,$gender,$qualification,$experience,$specialisation,$category,$telephone,$document)
	{
		$chex=$this->icon->query("SELECT * FROM employees_tb SET WHERE telephone='$telephone'");
		$num=$chex->num_rows;
		if ($num==1) {
			echo "<script>alert('Employee already exists !')</script>";
			echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
		}
		else{
			$tempname=$_FILES['document']['tmp_name'];
	        $orignalname=$_FILES['document']['name'];
	        $size=($_FILES['document']['size']/5242880)."MB <br>";
	        $type=$_FILES['document']['type'];
	        $document=$_FILES['document']['name'];
	        move_uploaded_file($_FILES['document']['tmp_name'],"docs/documents/".$_FILES["document"]["name"]);
			$addhr=$this->icon->query("INSERT INTO employees_tb SET names='$names',gender='$gender',role='Medicalworker',qualification='$qualification',experience='$experience',specialisation='$specialisation',category='$category',telephone='$telephone',document='$document',status='".date("d/m/Y")."' ");
			try {
				if ($addhr) {
					echo "<script>alert('Medicalworker has been added !')</script>";
					echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
				}
				else{
					echo "<script>alert('Error occured while adding Medicalworker !')</script>";
					echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
				}
			} catch (Exception $e) {
				$e->getMessage();
			}
		}
		
	}
	public function FetchMedicalworker()
	{
		$fthr=$this->icon->query("SELECT * FROM employees_tb WHERE role='Medicalworker' ORDER BY employee_id DESC");
		?>
		<div style="height: 500px; overflow: auto; text-transform: capitalize;">
			<table class="table table-striped table-bordered table-responsive table-hover small">
				<tr>
					<th>Names</th>
					<th>Gender</th>
					<th>Qualifications</th>
					<th>Experience</th>
					<th>Specialisation</th>
					<th>Category</th>
					<th>Contact</th>
					<th>Documents</th>
					<th>Edit / Del</th>
				</tr>
			
			<?php
			foreach($fthr as $row) {
				$employee_id=$row['employee_id'];
				$document=$row['document'];
				echo "<tr>";
				echo "<td>".$row['names']."</td>";
				echo "<td>".$row['gender'];
				if ($row['status']==date("d/m/Y")) {
					echo "&nbsp<i style='font-size: 11px; background-color: #ff0000; color:#fff; padding: 1px;'>new</i>";
				}
				echo "</td>";
				echo "<td>".$row['qualification']."</td>";
				echo "<td>".$row['experience']."</td>";				
				echo "<td>".$row['specialisation']."</td>";
				echo "<td>".$row['category']."</td>";
				echo "<td>".$row['telephone']."</td>";
				echo "<td><a href='includes/downloaddocument.php?download=".$document."' class='btn btn-xs btn-success br-radius-zero'><i class='fa fa-download'>&nbsp</i>Downoad</a></td>";
				echo "<td style='padding-right: 0px;' margin-right: 0px;>
						<a href='#editemp".$employee_id."' class='btn btn-xs btn-primary' data-toggle='modal'><i class='fa fa-edit'>&nbsp</i></a>
						<a href='includes/deleteemp.php?employee_id=".$employee_id."' class='btn btn-xs btn-danger' onclick='return Comfirm();')><i class='fa fa-trash-o'>&nbsp</i></a>

						</td>";
				echo "</tr>";
				include 'includes/editemp.php';
			}
			?>
			</table>
		</div>
		<?php	
		
	}

	public function AddFinacialmanagerQuery($names,$gender,$qualification,$experience,$specialisation,$category,$telephone,$document)
	{
		$chex=$this->icon->query("SELECT * FROM employees_tb SET WHERE telephone='$telephone'");
		$num=$chex->num_rows;
		if ($num==1) {
			echo "<script>alert('Employee already exists !')</script>";
			echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
		}
		else{
			$tempname=$_FILES['document']['tmp_name'];
	        $orignalname=$_FILES['document']['name'];
	        $size=($_FILES['document']['size']/5242880)."MB <br>";
	        $type=$_FILES['document']['type'];
	        $document=$_FILES['document']['name'];
	        move_uploaded_file($_FILES['document']['tmp_name'],"docs/documents/".$_FILES["document"]["name"]);
			$addhr=$this->icon->query("INSERT INTO employees_tb SET names='$names',gender='$gender',role='Finacialmanager',qualification='$qualification',experience='$experience',specialisation='$specialisation',category='$category',telephone='$telephone',document='$document',status='".date("d/m/Y")."' ");
			try {
				if ($addhr) {
					echo "<script>alert('Finacialmanager has been added !')</script>";
					echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
				}
				else{
					echo "<script>alert('Error occured while adding Finacialmanager !')</script>";
					echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
				}
			} catch (Exception $e) {
				$e->getMessage();
			}
		}
		
	}
	public function FetchFinacialmanager()
	{
		$fthr=$this->icon->query("SELECT * FROM employees_tb WHERE role='Finacialmanager' ORDER BY employee_id DESC");
		?>
		<div style="height: 500px; overflow: auto; text-transform: capitalize;">
			<table class="table table-striped table-bordered table-responsive table-hover small">
				<tr>
					<th>Names</th>
					<th>Gender</th>
					<th>Qualifications</th>
					<th>Experience</th>
					<th>Specialisation</th>
					<th>Category</th>
					<th>Contact</th>
					<th>Documents</th>
					<th>Edit / Del</th>
				</tr>
			
			<?php
			foreach($fthr as $row) {
				$employee_id=$row['employee_id'];
				$document=$row['document'];
				echo "<tr>";
				echo "<td>".$row['names']."</td>";
				echo "<td>".$row['gender'];
				if ($row['status']==date("d/m/Y")) {
					echo "&nbsp<i style='font-size: 11px; background-color: #ff0000; color:#fff; padding: 1px;'>new</i>";
				}
				echo "</td>";
				echo "<td>".$row['qualification']."</td>";
				echo "<td>".$row['experience']."</td>";				
				echo "<td>".$row['specialisation']."</td>";
				echo "<td>".$row['category']."</td>";
				echo "<td>".$row['telephone']."</td>";
				echo "<td><a href='includes/downloaddocument.php?download=".$document."' class='btn btn-xs btn-success br-radius-zero'><i class='fa fa-download'>&nbsp</i>Downoad</a></td>";
				echo "<td style='padding-right: 0px;' margin-right: 0px;>
						<a href='#editemp".$employee_id."' class='btn btn-xs btn-primary' data-toggle='modal'><i class='fa fa-edit'>&nbsp</i></a>
						<a href='includes/deleteemp.php?employee_id=".$employee_id."' class='btn btn-xs btn-danger' onclick='return Comfirm();')><i class='fa fa-trash-o'>&nbsp</i></a>

						</td>";
				echo "</tr>";
				include 'includes/editemp.php';
			}
			?>
			</table>
		</div>
		<?php	
		
	}

	public function AddExecutivemanagerQuery($names,$gender,$qualification,$experience,$specialisation,$category,$telephone,$document)
	{
		$chex=$this->icon->query("SELECT * FROM employees_tb SET WHERE telephone='$telephone'");
		$num=$chex->num_rows;
		if ($num==1) {
			echo "<script>alert('Employee already exists !')</script>";
			echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
		}
		else{
			$tempname=$_FILES['document']['tmp_name'];
	        $orignalname=$_FILES['document']['name'];
	        $size=($_FILES['document']['size']/5242880)."MB <br>";
	        $type=$_FILES['document']['type'];
	        $document=$_FILES['document']['name'];
	        move_uploaded_file($_FILES['document']['tmp_name'],"docs/documents/".$_FILES["document"]["name"]);
			$addhr=$this->icon->query("INSERT INTO employees_tb SET names='$names',gender='$gender',role='Executivemanager',qualification='$qualification',experience='$experience',specialisation='$specialisation',category='$category',telephone='$telephone',document='$document',status='".date("d/m/Y")."' ");
			try {
				if ($addhr) {
					echo "<script>alert('Executivemanager has been added !')</script>";
					echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
				}
				else{
					echo "<script>alert('Error occured while adding Executivemanager !')</script>";
					echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
				}
			} catch (Exception $e) {
				$e->getMessage();
			}
		}
		
	}
	public function FetchExecutivemanager()
	{
		$fthr=$this->icon->query("SELECT * FROM employees_tb WHERE role='Executivemanager' ORDER BY employee_id DESC");
		?>
		<div style="height: 500px; overflow: auto; text-transform: capitalize;">
			<table class="table table-striped table-bordered table-responsive table-hover small">
				<tr>
					<th>Names</th>
					<th>Gender</th>
					<th>Qualifications</th>
					<th>Experience</th>
					<th>Specialisation</th>
					<th>Category</th>
					<th>Contact</th>
					<th>Documents</th>
					<th>Edit / Del</th>
				</tr>
			
			<?php
			foreach($fthr as $row) {
				$employee_id=$row['employee_id'];
				$document=$row['document'];
				echo "<tr>";
				echo "<td>".$row['names']."</td>";
				echo "<td>".$row['gender'];
				if ($row['status']==date("d/m/Y")) {
					echo "&nbsp<i style='font-size: 11px; background-color: #ff0000; color:#fff; padding: 1px;'>new</i>";
				}
				echo "</td>";
				echo "<td>".$row['qualification']."</td>";
				echo "<td>".$row['experience']."</td>";				
				echo "<td>".$row['specialisation']."</td>";
				echo "<td>".$row['category']."</td>";
				echo "<td>".$row['telephone']."</td>";
				echo "<td><a href='includes/downloaddocument.php?download=".$document."' class='btn btn-xs btn-success br-radius-zero'><i class='fa fa-download'>&nbsp</i>Downoad</a></td>";
				echo "<td style='padding-right: 0px;' margin-right: 0px;>
						<a href='#editemp".$employee_id."' class='btn btn-xs btn-primary' data-toggle='modal'><i class='fa fa-edit'>&nbsp</i></a>
						<a href='includes/deleteemp.php?employee_id=".$employee_id."' class='btn btn-xs btn-danger' onclick='return Comfirm();')><i class='fa fa-trash-o'>&nbsp</i></a>

						</td>";
				echo "</tr>";
				include 'includes/editemp.php';
			}
			?>
			</table>
		</div>
		<?php	
		
	}

	public function AddLegalrepresentativeQuery($names,$gender,$qualification,$experience,$specialisation,$category,$telephone,$document)
	{
		$chex=$this->icon->query("SELECT * FROM employees_tb SET WHERE telephone='$telephone'");
		$num=$chex->num_rows;
		if ($num==1) {
			echo "<script>alert('Employee already exists !')</script>";
			echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
		}
		else{
			$tempname=$_FILES['document']['tmp_name'];
	        $orignalname=$_FILES['document']['name'];
	        $size=($_FILES['document']['size']/5242880)."MB <br>";
	        $type=$_FILES['document']['type'];
	        $document=$_FILES['document']['name'];
	        move_uploaded_file($_FILES['document']['tmp_name'],"docs/documents/".$_FILES["document"]["name"]);
			$addhr=$this->icon->query("INSERT INTO employees_tb SET names='$names',gender='$gender',role='Legalrepresentative',qualification='$qualification',experience='$experience',specialisation='$specialisation',category='$category',telephone='$telephone',document='$document',status='".date("d/m/Y")."' ");
			try {
				if ($addhr) {
					echo "<script>alert('Legalrepresentative has been added !')</script>";
					echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
				}
				else{
					echo "<script>alert('Error occured while adding Legalrepresentative !')</script>";
					echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
				}
			} catch (Exception $e) {
				$e->getMessage();
			}
		}
		
	}
	public function FetchLegalrepresentative()
	{
		$fthr=$this->icon->query("SELECT * FROM employees_tb WHERE role='Legalrepresentative' ORDER BY employee_id DESC");
		?>
		<div style="height: 500px; overflow: auto; text-transform: capitalize;">
			<table class="table table-striped table-bordered table-responsive table-hover small">
				<tr>
					<th>Names</th>
					<th>Gender</th>
					<th>Qualifications</th>
					<th>Experience</th>
					<th>Specialisation</th>
					<th>Category</th>
					<th>Contact</th>
					<th>Documents</th>
					<th>Edit / Del</th>
				</tr>
			
			<?php
			foreach($fthr as $row) {
				$employee_id=$row['employee_id'];
				$document=$row['document'];
				echo "<tr>";
				echo "<td>".$row['names']."</td>";
				echo "<td>".$row['gender'];
				if ($row['status']==date("d/m/Y")) {
					echo "&nbsp<i style='font-size: 11px; background-color: #ff0000; color:#fff; padding: 1px;'>new</i>";
				}
				echo "</td>";
				echo "<td>".$row['qualification']."</td>";
				echo "<td>".$row['experience']."</td>";				
				echo "<td>".$row['specialisation']."</td>";
				echo "<td>".$row['category']."</td>";
				echo "<td>".$row['telephone']."</td>";
				echo "<td><a href='includes/downloaddocument.php?download=".$document."' class='btn btn-xs btn-success br-radius-zero'><i class='fa fa-download'>&nbsp</i>Downoad</a></td>";
				echo "<td style='padding-right: 0px;' margin-right: 0px;>
						<a href='#editemp".$employee_id."' class='btn btn-xs btn-primary' data-toggle='modal'><i class='fa fa-edit'>&nbsp</i></a>
						<a href='includes/deleteemp.php?employee_id=".$employee_id."' class='btn btn-xs btn-danger' onclick='return Comfirm();')><i class='fa fa-trash-o'>&nbsp</i></a>

						</td>";
				echo "</tr>";
				include 'includes/editemp.php';
			}
			?>
			</table>
		</div>
		<?php	
		
	}
	

	public function AddMarketingmanagerQuery($names,$gender,$qualification,$experience,$specialisation,$category,$telephone,$document)
	{
		$chex=$this->icon->query("SELECT * FROM employees_tb SET WHERE telephone='$telephone'");
		$num=$chex->num_rows;
		if ($num==1) {
			echo "<script>alert('Employee already exists !')</script>";
			echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
		}
		else{
			$tempname=$_FILES['document']['tmp_name'];
	        $orignalname=$_FILES['document']['name'];
	        $size=($_FILES['document']['size']/5242880)."MB <br>";
	        $type=$_FILES['document']['type'];
	        $document=$_FILES['document']['name'];
	        move_uploaded_file($_FILES['document']['tmp_name'],"docs/documents/".$_FILES["document"]["name"]);
			$addhr=$this->icon->query("INSERT INTO employees_tb SET names='$names',gender='$gender',role='Marketingmanager',qualification='$qualification',experience='$experience',specialisation='$specialisation',category='$category',telephone='$telephone',document='$document',status='".date("d/m/Y")."' ");
			try {
				if ($addhr) {
					echo "<script>alert('Marketing manager has been added !')</script>";
					echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
				}
				else{
					echo "<script>alert('Error occured while adding Marketing manager !')</script>";
					echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
				}
			} catch (Exception $e) {
				$e->getMessage();
			}
		}
		
	}
	public function FetchMarketingmanager()
	{
		$fthr=$this->icon->query("SELECT * FROM employees_tb WHERE role='Marketingmanager' ORDER BY employee_id DESC");
		?>
		<div style="height: 500px; overflow: auto; text-transform: capitalize;">
			<table class="table table-striped table-bordered table-responsive table-hover small">
				<tr>
					<th>Names</th>
					<th>Gender</th>
					<th>Qualifications</th>
					<th>Experience</th>
					<th>Specialisation</th>
					<th>Category</th>
					<th>Contact</th>
					<th>Documents</th>
					<th>Edit / Del</th>
				</tr>
			
			<?php
			foreach($fthr as $row) {
				$employee_id=$row['employee_id'];
				$document=$row['document'];
				echo "<tr>";
				echo "<td>".$row['names']."</td>";
				echo "<td>".$row['gender'];
				if ($row['status']==date("d/m/Y")) {
					echo "&nbsp<i style='font-size: 11px; background-color: #ff0000; color:#fff; padding: 1px;'>new</i>";
				}
				echo "</td>";
				echo "<td>".$row['qualification']."</td>";
				echo "<td>".$row['experience']."</td>";				
				echo "<td>".$row['specialisation']."</td>";
				echo "<td>".$row['category']."</td>";
				echo "<td>".$row['telephone']."</td>";
				echo "<td><a href='includes/downloaddocument.php?download=".$document."' class='btn btn-xs btn-success br-radius-zero'><i class='fa fa-download'>&nbsp</i>Downoad</a></td>";
				echo "<td style='padding-right: 0px;' margin-right: 0px;>
						<a href='#editemp".$employee_id."' class='btn btn-xs btn-primary' data-toggle='modal'><i class='fa fa-edit'>&nbsp</i></a>
						<a href='includes/deleteemp.php?employee_id=".$employee_id."' class='btn btn-xs btn-danger' onclick='return Comfirm();')><i class='fa fa-trash-o'>&nbsp</i></a>

						</td>";
				echo "</tr>";
				include 'includes/editemp.php';
			}
			?>
			</table>
		</div>
		<?php	
		
	}

	public function AddTeachersQuery($names,$gender,$qualification,$experience,$specialisation,$category,$telephone,$document)
	{
		$chex=$this->icon->query("SELECT * FROM employees_tb SET WHERE telephone='$telephone'");
		$num=$chex->num_rows;
		if ($num==1) {
			echo "<script>alert('Employee already exists !')</script>";
			echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
		}
		else{
			$tempname=$_FILES['document']['tmp_name'];
	        $orignalname=$_FILES['document']['name'];
	        $size=($_FILES['document']['size']/5242880)."MB <br>";
	        $type=$_FILES['document']['type'];
	        $document=$_FILES['document']['name'];
	        move_uploaded_file($_FILES['document']['tmp_name'],"docs/documents/".$_FILES["document"]["name"]);
			$addhr=$this->icon->query("INSERT INTO employees_tb SET names='$names',gender='$gender',role='Teachers',qualification='$qualification',experience='$experience',specialisation='$specialisation',category='$category',telephone='$telephone',document='$document',status='".date("d/m/Y")."' ");
			try {
				if ($addhr) {
					echo "<script>alert('Teachers has been added !')</script>";
					echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
				}
				else{
					echo "<script>alert('Error occured while adding Teachers !')</script>";
					echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
				}
			} catch (Exception $e) {
				$e->getMessage();
			}
		}
		
	}
	public function FetchTeachers()
	{
		$fthr=$this->icon->query("SELECT * FROM employees_tb WHERE role='Teachers' ORDER BY employee_id DESC");
		?>
		<div style="height: 500px; overflow: auto; text-transform: capitalize;">
			<table class="table table-striped table-bordered table-responsive table-hover small">
				<tr>
					<th>Names</th>
					<th>Gender</th>
					<th>Qualifications</th>
					<th>Experience</th>
					<th>Specialisation</th>
					<th>Category</th>
					<th>Contact</th>
					<th>Documents</th>
					<th>Edit / Del</th>
				</tr>
			
			<?php
			foreach($fthr as $row) {
				$employee_id=$row['employee_id'];
				$document=$row['document'];
				echo "<tr>";
				echo "<td>".$row['names']."</td>";
				echo "<td>".$row['gender'];
				if ($row['status']==date("d/m/Y")) {
					echo "&nbsp<i style='font-size: 11px; background-color: #ff0000; color:#fff; padding: 1px;'>new</i>";
				}
				echo "</td>";
				echo "<td>".$row['qualification']."</td>";
				echo "<td>".$row['experience']."</td>";				
				echo "<td>".$row['specialisation']."</td>";
				echo "<td>".$row['category']."</td>";
				echo "<td>".$row['telephone']."</td>";
				echo "<td><a href='includes/downloaddocument.php?download=".$document."' class='btn btn-xs btn-success br-radius-zero'><i class='fa fa-download'>&nbsp</i>Downoad</a></td>";
				echo "<td style='padding-right: 0px;' margin-right: 0px;>
						<a href='#editemp".$employee_id."' class='btn btn-xs btn-primary' data-toggle='modal'><i class='fa fa-edit'>&nbsp</i></a>
						<a href='includes/deleteemp.php?employee_id=".$employee_id."' class='btn btn-xs btn-danger' onclick='return Comfirm();')><i class='fa fa-trash-o'>&nbsp</i></a>

						</td>";
				echo "</tr>";
				include 'includes/editemp.php';
			}
			?>
			</table>
		</div>
		<?php	
		
	}

	public function AddPaintersQuery($names,$gender,$qualification,$experience,$specialisation,$category,$telephone,$document)
	{
		$chex=$this->icon->query("SELECT * FROM employees_tb SET WHERE telephone='$telephone'");
		$num=$chex->num_rows;
		if ($num==1) {
			echo "<script>alert('Employee already exists !')</script>";
			echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
		}
		else{
			$tempname=$_FILES['document']['tmp_name'];
	        $orignalname=$_FILES['document']['name'];
	        $size=($_FILES['document']['size']/5242880)."MB <br>";
	        $type=$_FILES['document']['type'];
	        $document=$_FILES['document']['name'];
	        move_uploaded_file($_FILES['document']['tmp_name'],"docs/documents/".$_FILES["document"]["name"]);
			$addhr=$this->icon->query("INSERT INTO employees_tb SET names='$names',gender='$gender',role='Painters',qualification='$qualification',experience='$experience',specialisation='$specialisation',category='$category',telephone='$telephone',document='$document',status='".date("d/m/Y")."' ");
			try {
				if ($addhr) {
					echo "<script>alert('Painters has been added !')</script>";
					echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
				}
				else{
					echo "<script>alert('Error occured while adding Painters !')</script>";
					echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
				}
			} catch (Exception $e) {
				$e->getMessage();
			}
		}
		
	}
	public function FetchPainters()
	{
		$fthr=$this->icon->query("SELECT * FROM employees_tb WHERE role='Painters' ORDER BY employee_id DESC");
		?>
		<div style="height: 500px; overflow: auto; text-transform: capitalize;">
			<table class="table table-striped table-bordered table-responsive table-hover small">
				<tr>
					<th>Names</th>
					<th>Gender</th>
					<th>Qualifications</th>
					<th>Experience</th>
					<th>Specialisation</th>
					<th>Category</th>
					<th>Contact</th>
					<th>Documents</th>
					<th>Edit / Del</th>
				</tr>
			
			<?php
			foreach($fthr as $row) {
				$employee_id=$row['employee_id'];
				$document=$row['document'];
				echo "<tr>";
				echo "<td>".$row['names']."</td>";
				echo "<td>".$row['gender'];
				if ($row['status']==date("d/m/Y")) {
					echo "&nbsp<i style='font-size: 11px; background-color: #ff0000; color:#fff; padding: 1px;'>new</i>";
				}
				echo "</td>";
				echo "<td>".$row['qualification']."</td>";
				echo "<td>".$row['experience']."</td>";				
				echo "<td>".$row['specialisation']."</td>";
				echo "<td>".$row['category']."</td>";
				echo "<td>".$row['telephone']."</td>";
				echo "<td><a href='includes/downloaddocument.php?download=".$document."' class='btn btn-xs btn-success br-radius-zero'><i class='fa fa-download'>&nbsp</i>Downoad</a></td>";
				echo "<td style='padding-right: 0px;' margin-right: 0px;>
						<a href='#editemp".$employee_id."' class='btn btn-xs btn-primary' data-toggle='modal'><i class='fa fa-edit'>&nbsp</i></a>
						<a href='includes/deleteemp.php?employee_id=".$employee_id."' class='btn btn-xs btn-danger' onclick='return Comfirm();')><i class='fa fa-trash-o'>&nbsp</i></a>

						</td>";
				echo "</tr>";
				include 'includes/editemp.php';
			}
			?>
			</table>
		</div>
		<?php	
		
	}

	public function AddReceptionistsQuery($names,$gender,$qualification,$experience,$specialisation,$category,$telephone,$document)
	{
		$chex=$this->icon->query("SELECT * FROM employees_tb SET WHERE telephone='$telephone'");
		$num=$chex->num_rows;
		if ($num==1) {
			echo "<script>alert('Employee already exists !')</script>";
			echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
		}
		else{
			$tempname=$_FILES['document']['tmp_name'];
	        $orignalname=$_FILES['document']['name'];
	        $size=($_FILES['document']['size']/5242880)."MB <br>";
	        $type=$_FILES['document']['type'];
	        $document=$_FILES['document']['name'];
	        move_uploaded_file($_FILES['document']['tmp_name'],"docs/documents/".$_FILES["document"]["name"]);
			$addhr=$this->icon->query("INSERT INTO employees_tb SET names='$names',gender='$gender',role='Receptionists',qualification='$qualification',experience='$experience',specialisation='$specialisation',category='$category',telephone='$telephone',document='$document',status='".date("d/m/Y")."' ");
			try {
				if ($addhr) {
					echo "<script>alert('Receptionists has been added !')</script>";
					echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
				}
				else{
					echo "<script>alert('Error occured while adding Receptionists !')</script>";
					echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
				}
			} catch (Exception $e) {
				$e->getMessage();
			}
		}
		
	}
	public function FetchReceptionists()
	{
		$fthr=$this->icon->query("SELECT * FROM employees_tb WHERE role='Receptionists' ORDER BY employee_id DESC");
		?>
		<div style="height: 500px; overflow: auto; text-transform: capitalize;">
			<table class="table table-striped table-bordered table-responsive table-hover small">
				<tr>
					<th>Names</th>
					<th>Gender</th>
					<th>Qualifications</th>
					<th>Experience</th>
					<th>Specialisation</th>
					<th>Category</th>
					<th>Contact</th>
					<th>Documents</th>
					<th>Edit / Del</th>
				</tr>
			
			<?php
			foreach($fthr as $row) {
				$employee_id=$row['employee_id'];
				$document=$row['document'];
				echo "<tr>";
				echo "<td>".$row['names']."</td>";
				echo "<td>".$row['gender'];
				if ($row['status']==date("d/m/Y")) {
					echo "&nbsp<i style='font-size: 11px; background-color: #ff0000; color:#fff; padding: 1px;'>new</i>";
				}
				echo "</td>";
				echo "<td>".$row['qualification']."</td>";
				echo "<td>".$row['experience']."</td>";				
				echo "<td>".$row['specialisation']."</td>";
				echo "<td>".$row['category']."</td>";
				echo "<td>".$row['telephone']."</td>";
				echo "<td><a href='includes/downloaddocument.php?download=".$document."' class='btn btn-xs btn-success br-radius-zero'><i class='fa fa-download'>&nbsp</i>Downoad</a></td>";
				echo "<td style='padding-right: 0px;' margin-right: 0px;>
						<a href='#editemp".$employee_id."' class='btn btn-xs btn-primary' data-toggle='modal'><i class='fa fa-edit'>&nbsp</i></a>
						<a href='includes/deleteemp.php?employee_id=".$employee_id."' class='btn btn-xs btn-danger' onclick='return Comfirm();')><i class='fa fa-trash-o'>&nbsp</i></a>

						</td>";
				echo "</tr>";
				include 'includes/editemp.php';
			}
			?>
			</table>
		</div>
		<?php	
		
	}

	public function AddDriversQuery($names,$gender,$qualification,$experience,$specialisation,$category,$telephone,$document)
	{
		$chex=$this->icon->query("SELECT * FROM employees_tb SET WHERE telephone='$telephone'");
		$num=$chex->num_rows;
		if ($num==1) {
			echo "<script>alert('Employee already exists !')</script>";
			echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
		}
		else{
			$tempname=$_FILES['document']['tmp_name'];
	        $orignalname=$_FILES['document']['name'];
	        $size=($_FILES['document']['size']/5242880)."MB <br>";
	        $type=$_FILES['document']['type'];
	        $document=$_FILES['document']['name'];
	        move_uploaded_file($_FILES['document']['tmp_name'],"docs/documents/".$_FILES["document"]["name"]);
			$addhr=$this->icon->query("INSERT INTO employees_tb SET names='$names',gender='$gender',role='Drivers',qualification='$qualification',experience='$experience',specialisation='$specialisation',category='$category',telephone='$telephone',document='$document',status='".date("d/m/Y")."' ");
			try {
				if ($addhr) {
					echo "<script>alert('Drivers has been added !')</script>";
					echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
				}
				else{
					echo "<script>alert('Error occured while adding Drivers !')</script>";
					echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
				}
			} catch (Exception $e) {
				$e->getMessage();
			}
		}
		
	}
	public function FetchDrivers()
	{
		$fthr=$this->icon->query("SELECT * FROM employees_tb WHERE role='Drivers' ORDER BY employee_id DESC");
		?>
		<div style="height: 500px; overflow: auto; text-transform: capitalize;">
			<table class="table table-striped table-bordered table-responsive table-hover small">
				<tr>
					<th>Names</th>
					<th>Gender</th>
					<th>Qualifications</th>
					<th>Experience</th>
					<th>Specialisation</th>
					<th>Category</th>
					<th>Contact</th>
					<th>Documents</th>
					<th>Edit / Del</th>
				</tr>
			
			<?php
			foreach($fthr as $row) {
				$employee_id=$row['employee_id'];
				$document=$row['document'];
				echo "<tr>";
				echo "<td>".$row['names']."</td>";
				echo "<td>".$row['gender'];
				if ($row['status']==date("d/m/Y")) {
					echo "&nbsp<i style='font-size: 11px; background-color: #ff0000; color:#fff; padding: 1px;'>new</i>";
				}
				echo "</td>";
				echo "<td>".$row['qualification']."</td>";
				echo "<td>".$row['experience']."</td>";				
				echo "<td>".$row['specialisation']."</td>";
				echo "<td>".$row['category']."</td>";
				echo "<td>".$row['telephone']."</td>";
				echo "<td><a href='includes/downloaddocument.php?download=".$document."' class='btn btn-xs btn-success br-radius-zero'><i class='fa fa-download'>&nbsp</i>Downoad</a></td>";
				echo "<td style='padding-right: 0px;' margin-right: 0px;>
						<a href='#editemp".$employee_id."' class='btn btn-xs btn-primary' data-toggle='modal'><i class='fa fa-edit'>&nbsp</i></a>
						<a href='includes/deleteemp.php?employee_id=".$employee_id."' class='btn btn-xs btn-danger' onclick='return Comfirm();')><i class='fa fa-trash-o'>&nbsp</i></a>

						</td>";
				echo "</tr>";
				include 'includes/editemp.php';
			}
			?>
			</table>
		</div>
		<?php	
		
	}

	public function AddSecurityguardsQuery($names,$gender,$qualification,$experience,$specialisation,$category,$telephone,$document)
	{
		$chex=$this->icon->query("SELECT * FROM employees_tb SET WHERE telephone='$telephone'");
		$num=$chex->num_rows;
		if ($num==1) {
			echo "<script>alert('Employee already exists !')</script>";
			echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
		}
		else{
			$tempname=$_FILES['document']['tmp_name'];
	        $orignalname=$_FILES['document']['name'];
	        $size=($_FILES['document']['size']/5242880)."MB <br>";
	        $type=$_FILES['document']['type'];
	        $document=$_FILES['document']['name'];
	        move_uploaded_file($_FILES['document']['tmp_name'],"docs/documents/".$_FILES["document"]["name"]);
			$addhr=$this->icon->query("INSERT INTO employees_tb SET names='$names',gender='$gender',role='Securityguards',qualification='$qualification',experience='$experience',specialisation='$specialisation',category='$category',telephone='$telephone',document='$document',status='".date("d/m/Y")."' ");
			try {
				if ($addhr) {
					echo "<script>alert('Security guards has been added !')</script>";
					echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
				}
				else{
					echo "<script>alert('Error occured while adding Security guards !')</script>";
					echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
				}
			} catch (Exception $e) {
				$e->getMessage();
			}
		}
		
	}
	public function FetchSecurityguards()
	{
		$fthr=$this->icon->query("SELECT * FROM employees_tb WHERE role='Securityguards' ORDER BY employee_id DESC");
		?>
		<div style="height: 500px; overflow: auto; text-transform: capitalize;">
			<table class="table table-striped table-bordered table-responsive table-hover small">
				<tr>
					<th>Names</th>
					<th>Gender</th>
					<th>Qualifications</th>
					<th>Experience</th>
					<th>Specialisation</th>
					<th>Category</th>
					<th>Contact</th>
					<th>Documents</th>
					<th>Edit / Del</th>
				</tr>
			
			<?php
			foreach($fthr as $row) {
				$employee_id=$row['employee_id'];
				$document=$row['document'];
				echo "<tr>";
				echo "<td>".$row['names']."</td>";
				echo "<td>".$row['gender'];
				if ($row['status']==date("d/m/Y")) {
					echo "&nbsp<i style='font-size: 11px; background-color: #ff0000; color:#fff; padding: 1px;'>new</i>";
				}
				echo "</td>";
				echo "<td>".$row['qualification']."</td>";
				echo "<td>".$row['experience']."</td>";				
				echo "<td>".$row['specialisation']."</td>";
				echo "<td>".$row['category']."</td>";
				echo "<td>".$row['telephone']."</td>";
				echo "<td><a href='includes/downloaddocument.php?download=".$document."' class='btn btn-xs btn-success br-radius-zero'><i class='fa fa-download'>&nbsp</i>Downoad</a></td>";
				echo "<td style='padding-right: 0px;' margin-right: 0px;>
						<a href='#editemp".$employee_id."' class='btn btn-xs btn-primary' data-toggle='modal'><i class='fa fa-edit'>&nbsp</i></a>
						<a href='includes/deleteemp.php?employee_id=".$employee_id."' class='btn btn-xs btn-danger' onclick='return Comfirm();')><i class='fa fa-trash-o'>&nbsp</i></a>

						</td>";
				echo "</tr>";
				include 'includes/editemp.php';
			}
			?>
			</table>
		</div>
		<?php	
		
	}

	public function AddDataenteriesQuery($names,$gender,$qualification,$experience,$specialisation,$category,$telephone,$document)
	{
		$chex=$this->icon->query("SELECT * FROM employees_tb SET WHERE telephone='$telephone'");
		$num=$chex->num_rows;
		if ($num==1) {
			echo "<script>alert('Employee already exists !')</script>";
			echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
		}
		else{
			$tempname=$_FILES['document']['tmp_name'];
	        $orignalname=$_FILES['document']['name'];
	        $size=($_FILES['document']['size']/5242880)."MB <br>";
	        $type=$_FILES['document']['type'];
	        $document=$_FILES['document']['name'];
	        move_uploaded_file($_FILES['document']['tmp_name'],"docs/documents/".$_FILES["document"]["name"]);
			$addhr=$this->icon->query("INSERT INTO employees_tb SET names='$names',gender='$gender',role='Dataenteries',qualification='$qualification',experience='$experience',specialisation='$specialisation',category='$category',telephone='$telephone',document='$document',status='".date("d/m/Y")."' ");
			try {
				if ($addhr) {
					echo "<script>alert('Data enteries has been added !')</script>";
					echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
				}
				else{
					echo "<script>alert('Error occured while adding Data enteries !')</script>";
					echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
				}
			} catch (Exception $e) {
				$e->getMessage();
			}
		}
		
	}
	public function FetchDataenteries()
	{
		$fthr=$this->icon->query("SELECT * FROM employees_tb WHERE role='Dataenteries' ORDER BY employee_id DESC");
		?>
		<div style="height: 500px; overflow: auto; text-transform: capitalize;">
			<table class="table table-striped table-bordered table-responsive table-hover small">
				<tr>
					<th>Names</th>
					<th>Gender</th>
					<th>Qualifications</th>
					<th>Experience</th>
					<th>Specialisation</th>
					<th>Category</th>
					<th>Contact</th>
					<th>Documents</th>
					<th>Edit / Del</th>
				</tr>
			
			<?php
			foreach($fthr as $row) {
				$employee_id=$row['employee_id'];
				$document=$row['document'];
				echo "<tr>";
				echo "<td>".$row['names']."</td>";
				echo "<td>".$row['gender'];
				if ($row['status']==date("d/m/Y")) {
					echo "&nbsp<i style='font-size: 11px; background-color: #ff0000; color:#fff; padding: 1px;'>new</i>";
				}
				echo "</td>";
				echo "<td>".$row['qualification']."</td>";
				echo "<td>".$row['experience']."</td>";				
				echo "<td>".$row['specialisation']."</td>";
				echo "<td>".$row['category']."</td>";
				echo "<td>".$row['telephone']."</td>";
				echo "<td><a href='includes/downloaddocument.php?download=".$document."' class='btn btn-xs btn-success br-radius-zero'><i class='fa fa-download'>&nbsp</i>Downoad</a></td>";
				echo "<td style='padding-right: 0px;' margin-right: 0px;>
						<a href='#editemp".$employee_id."' class='btn btn-xs btn-primary' data-toggle='modal'><i class='fa fa-edit'>&nbsp</i></a>
						<a href='includes/deleteemp.php?employee_id=".$employee_id."' class='btn btn-xs btn-danger' onclick='return Comfirm();')><i class='fa fa-trash-o'>&nbsp</i></a>

						</td>";
				echo "</tr>";
				include 'includes/editemp.php';
			}
			?>
			</table>
		</div>
		<?php	
		
	}

	public function AddSecriteriesQuery($names,$gender,$qualification,$experience,$specialisation,$category,$telephone,$document)
	{
		$chex=$this->icon->query("SELECT * FROM employees_tb SET WHERE telephone='$telephone'");
		$num=$chex->num_rows;
		if ($num==1) {
			echo "<script>alert('Employee already exists !')</script>";
			echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
		}
		else{
			$tempname=$_FILES['document']['tmp_name'];
	        $orignalname=$_FILES['document']['name'];
	        $size=($_FILES['document']['size']/5242880)."MB <br>";
	        $type=$_FILES['document']['type'];
	        $document=$_FILES['document']['name'];
	        move_uploaded_file($_FILES['document']['tmp_name'],"docs/documents/".$_FILES["document"]["name"]);
			$addhr=$this->icon->query("INSERT INTO employees_tb SET names='$names',gender='$gender',role='Secriteries',qualification='$qualification',experience='$experience',specialisation='$specialisation',category='$category',telephone='$telephone',document='$document',status='".date("d/m/Y")."' ");
			try {
				if ($addhr) {
					echo "<script>alert('Secriteries has been added !')</script>";
					echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
				}
				else{
					echo "<script>alert('Error occured while adding Secriteries !')</script>";
					echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
				}
			} catch (Exception $e) {
				$e->getMessage();
			}
		}
		
	}
	public function FetchSecriteries()
	{
		$fthr=$this->icon->query("SELECT * FROM employees_tb WHERE role='Secriteries' ORDER BY employee_id DESC");
		?>
		<div style="height: 500px; overflow: auto; text-transform: capitalize;">
			<table class="table table-striped table-bordered table-responsive table-hover small">
				<tr>
					<th>Names</th>
					<th>Gender</th>
					<th>Qualifications</th>
					<th>Experience</th>
					<th>Specialisation</th>
					<th>Category</th>
					<th>Contact</th>
					<th>Documents</th>
					<th>Edit / Del</th>
				</tr>
			
			<?php
			foreach($fthr as $row) {
				$employee_id=$row['employee_id'];
				$document=$row['document'];
				echo "<tr>";
				echo "<td>".$row['names']."</td>";
				echo "<td>".$row['gender'];
				if ($row['status']==date("d/m/Y")) {
					echo "&nbsp<i style='font-size: 11px; background-color: #ff0000; color:#fff; padding: 1px;'>new</i>";
				}
				echo "</td>";
				echo "<td>".$row['qualification']."</td>";
				echo "<td>".$row['experience']."</td>";				
				echo "<td>".$row['specialisation']."</td>";
				echo "<td>".$row['category']."</td>";
				echo "<td>".$row['telephone']."</td>";
				echo "<td><a href='includes/downloaddocument.php?download=".$document."' class='btn btn-xs btn-success br-radius-zero'><i class='fa fa-download'>&nbsp</i>Downoad</a></td>";
				echo "<td style='padding-right: 0px;' margin-right: 0px;>
						<a href='#editemp".$employee_id."' class='btn btn-xs btn-primary' data-toggle='modal'><i class='fa fa-edit'>&nbsp</i></a>
						<a href='includes/deleteemp.php?employee_id=".$employee_id."' class='btn btn-xs btn-danger' onclick='return Comfirm();')><i class='fa fa-trash-o'>&nbsp</i></a>

						</td>";
				echo "</tr>";
				include 'includes/editemp.php';
			}
			?>
			</table>
		</div>
		<?php	
		
	}

	public function AddOfficeassistantsQuery($names,$gender,$qualification,$experience,$specialisation,$category,$telephone,$document)
	{
		$chex=$this->icon->query("SELECT * FROM employees_tb SET WHERE telephone='$telephone'");
		$num=$chex->num_rows;
		if ($num==1) {
			echo "<script>alert('Employee already exists !')</script>";
			echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
		}
		else{
			$tempname=$_FILES['document']['tmp_name'];
	        $orignalname=$_FILES['document']['name'];
	        $size=($_FILES['document']['size']/5242880)."MB <br>";
	        $type=$_FILES['document']['type'];
	        $document=$_FILES['document']['name'];
	        move_uploaded_file($_FILES['document']['tmp_name'],"docs/documents/".$_FILES["document"]["name"]);
			$addhr=$this->icon->query("INSERT INTO employees_tb SET names='$names',gender='$gender',role='Officeassistants',qualification='$qualification',experience='$experience',specialisation='$specialisation',category='$category',telephone='$telephone',document='$document',status='".date("d/m/Y")."' ");
			try {
				if ($addhr) {
					echo "<script>alert('Office assistants has been added !')</script>";
					echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
				}
				else{
					echo "<script>alert('Error occured while adding Office assistants !')</script>";
					echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
				}
			} catch (Exception $e) {
				$e->getMessage();
			}
		}
		
	}
	public function FetchOfficeassistants()
	{
		$fthr=$this->icon->query("SELECT * FROM employees_tb WHERE role='Officeassistants' ORDER BY employee_id DESC");
		?>
		<div style="height: 500px; overflow: auto; text-transform: capitalize;">
			<table class="table table-striped table-bordered table-responsive table-hover small">
				<tr>
					<th>Names</th>
					<th>Gender</th>
					<th>Qualifications</th>
					<th>Experience</th>
					<th>Specialisation</th>
					<th>Category</th>
					<th>Contact</th>
					<th>Documents</th>
					<th>Edit / Del</th>
				</tr>
			
			<?php
			foreach($fthr as $row) {
				$employee_id=$row['employee_id'];
				$document=$row['document'];
				echo "<tr>";
				echo "<td>".$row['names']."</td>";
				echo "<td>".$row['gender'];
				if ($row['status']==date("d/m/Y")) {
					echo "&nbsp<i style='font-size: 11px; background-color: #ff0000; color:#fff; padding: 1px;'>new</i>";
				}
				echo "</td>";
				echo "<td>".$row['qualification']."</td>";
				echo "<td>".$row['experience']."</td>";				
				echo "<td>".$row['specialisation']."</td>";
				echo "<td>".$row['category']."</td>";
				echo "<td>".$row['telephone']."</td>";
				echo "<td><a href='includes/downloaddocument.php?download=".$document."' class='btn btn-xs btn-success br-radius-zero'><i class='fa fa-download'>&nbsp</i>Downoad</a></td>";
				echo "<td style='padding-right: 0px;' margin-right: 0px;>
						<a href='#editemp".$employee_id."' class='btn btn-xs btn-primary' data-toggle='modal'><i class='fa fa-edit'>&nbsp</i></a>
						<a href='includes/deleteemp.php?employee_id=".$employee_id."' class='btn btn-xs btn-danger' onclick='return Comfirm();')><i class='fa fa-trash-o'>&nbsp</i></a>

						</td>";
				echo "</tr>";
				include 'includes/editemp.php';
			}
			?>
			</table>
		</div>
		<?php	
		
	}

	public function AddSalespersonelQuery($names,$gender,$qualification,$experience,$specialisation,$category,$telephone,$document)
	{
		$chex=$this->icon->query("SELECT * FROM employees_tb SET WHERE telephone='$telephone'");
		$num=$chex->num_rows;
		if ($num==1) {
			echo "<script>alert('Employee already exists !')</script>";
			echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
		}
		else{
			$tempname=$_FILES['document']['tmp_name'];
	        $orignalname=$_FILES['document']['name'];
	        $size=($_FILES['document']['size']/5242880)."MB <br>";
	        $type=$_FILES['document']['type'];
	        $document=$_FILES['document']['name'];
	        move_uploaded_file($_FILES['document']['tmp_name'],"docs/documents/".$_FILES["document"]["name"]);
			$addhr=$this->icon->query("INSERT INTO employees_tb SET names='$names',gender='$gender',role='Salespersonel',qualification='$qualification',experience='$experience',specialisation='$specialisation',category='$category',telephone='$telephone',document='$document',status='".date("d/m/Y")."' ");
			try {
				if ($addhr) {
					echo "<script>alert('Sales personel has been added !')</script>";
					echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
				}
				else{
					echo "<script>alert('Error occured while adding Sales personel !')</script>";
					echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
				}
			} catch (Exception $e) {
				$e->getMessage();
			}
		}
		
	}
	public function FetchSalespersonel()
	{
		$fthr=$this->icon->query("SELECT * FROM employees_tb WHERE role='Salespersonel' ORDER BY employee_id DESC");
		?>
		<div style="height: 500px; overflow: auto; text-transform: capitalize;">
			<table class="table table-striped table-bordered table-responsive table-hover small">
				<tr>
					<th>Names</th>
					<th>Gender</th>
					<th>Qualifications</th>
					<th>Experience</th>
					<th>Specialisation</th>
					<th>Category</th>
					<th>Contact</th>
					<th>Documents</th>
					<th>Edit / Del</th>
				</tr>
			
			<?php
			foreach($fthr as $row) {
				$employee_id=$row['employee_id'];
				$document=$row['document'];
				echo "<tr>";
				echo "<td>".$row['names']."</td>";
				echo "<td>".$row['gender'];
				if ($row['status']==date("d/m/Y")) {
					echo "&nbsp<i style='font-size: 11px; background-color: #ff0000; color:#fff; padding: 1px;'>new</i>";
				}
				echo "</td>";
				echo "<td>".$row['qualification']."</td>";
				echo "<td>".$row['experience']."</td>";				
				echo "<td>".$row['specialisation']."</td>";
				echo "<td>".$row['category']."</td>";
				echo "<td>".$row['telephone']."</td>";
				echo "<td><a href='includes/downloaddocument.php?download=".$document."' class='btn btn-xs btn-success br-radius-zero'><i class='fa fa-download'>&nbsp</i>Downoad</a></td>";
				echo "<td style='padding-right: 0px;' margin-right: 0px;>
						<a href='#editemp".$employee_id."' class='btn btn-xs btn-primary' data-toggle='modal'><i class='fa fa-edit'>&nbsp</i></a>
						<a href='includes/deleteemp.php?employee_id=".$employee_id."' class='btn btn-xs btn-danger' onclick='return Comfirm();')><i class='fa fa-trash-o'>&nbsp</i></a>

						</td>";
				echo "</tr>";
				include 'includes/editemp.php';
			}
			?>
			</table>
		</div>
		<?php	
		
	}

	public function AddStoremanagersQuery($names,$gender,$qualification,$experience,$specialisation,$category,$telephone,$document)
	{
		$chex=$this->icon->query("SELECT * FROM employees_tb SET WHERE telephone='$telephone'");
		$num=$chex->num_rows;
		if ($num==1) {
			echo "<script>alert('Employee already exists !')</script>";
			echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
		}
		else{
			$tempname=$_FILES['document']['tmp_name'];
	        $orignalname=$_FILES['document']['name'];
	        $size=($_FILES['document']['size']/5242880)."MB <br>";
	        $type=$_FILES['document']['type'];
	        $document=$_FILES['document']['name'];
	        move_uploaded_file($_FILES['document']['tmp_name'],"docs/documents/".$_FILES["document"]["name"]);
			$addhr=$this->icon->query("INSERT INTO employees_tb SET names='$names',gender='$gender',role='Storemanagers',qualification='$qualification',experience='$experience',specialisation='$specialisation',category='$category',telephone='$telephone',document='$document',status='".date("d/m/Y")."' ");
			try {
				if ($addhr) {
					echo "<script>alert('Store managers has been added !')</script>";
					echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
				}
				else{
					echo "<script>alert('Error occured while adding Store managers !')</script>";
					echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
				}
			} catch (Exception $e) {
				$e->getMessage();
			}
		}
		
	}
	public function FetchStoremanagers()
	{
		$fthr=$this->icon->query("SELECT * FROM employees_tb WHERE role='Storemanagers' ORDER BY employee_id DESC");
		?>
		<div style="height: 500px; overflow: auto; text-transform: capitalize;">
			<table class="table table-striped table-bordered table-responsive table-hover small">
				<tr>
					<th>Names</th>
					<th>Gender</th>
					<th>Qualifications</th>
					<th>Experience</th>
					<th>Specialisation</th>
					<th>Category</th>
					<th>Contact</th>
					<th>Documents</th>
					<th>Edit / Del</th>
				</tr>
			
			<?php
			foreach($fthr as $row) {
				$employee_id=$row['employee_id'];
				$document=$row['document'];
				echo "<tr>";
				echo "<td>".$row['names']."</td>";
				echo "<td>".$row['gender'];
				if ($row['status']==date("d/m/Y")) {
					echo "&nbsp<i style='font-size: 11px; background-color: #ff0000; color:#fff; padding: 1px;'>new</i>";
				}
				echo "</td>";
				echo "<td>".$row['qualification']."</td>";
				echo "<td>".$row['experience']."</td>";				
				echo "<td>".$row['specialisation']."</td>";
				echo "<td>".$row['category']."</td>";
				echo "<td>".$row['telephone']."</td>";
				echo "<td><a href='includes/downloaddocument.php?download=".$document."' class='btn btn-xs btn-success br-radius-zero'><i class='fa fa-download'>&nbsp</i>Downoad</a></td>";
				echo "<td style='padding-right: 0px;' margin-right: 0px;>
						<a href='#editemp".$employee_id."' class='btn btn-xs btn-primary' data-toggle='modal'><i class='fa fa-edit'>&nbsp</i></a>
						<a href='includes/deleteemp.php?employee_id=".$employee_id."' class='btn btn-xs btn-danger' onclick='return Comfirm();')><i class='fa fa-trash-o'>&nbsp</i></a>

						</td>";
				echo "</tr>";
				include 'includes/editemp.php';
			}
			?>
			</table>
		</div>
		<?php	
		
	}

	public function AddCateringservicesQuery($names,$gender,$qualification,$experience,$specialisation,$category,$telephone,$document)
	{
		$chex=$this->icon->query("SELECT * FROM employees_tb SET WHERE telephone='$telephone'");
		$num=$chex->num_rows;
		if ($num==1) {
			echo "<script>alert('Employee already exists !')</script>";
			echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
		}
		else{
			$tempname=$_FILES['document']['tmp_name'];
	        $orignalname=$_FILES['document']['name'];
	        $size=($_FILES['document']['size']/5242880)."MB <br>";
	        $type=$_FILES['document']['type'];
	        $document=$_FILES['document']['name'];
	        move_uploaded_file($_FILES['document']['tmp_name'],"docs/documents/".$_FILES["document"]["name"]);
			$addhr=$this->icon->query("INSERT INTO employees_tb SET names='$names',gender='$gender',role='Cateringservices',qualification='$qualification',experience='$experience',specialisation='$specialisation',category='$category',telephone='$telephone',document='$document',status='".date("d/m/Y")."' ");
			try {
				if ($addhr) {
					echo "<script>alert('Catering services has been added !')</script>";
					echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
				}
				else{
					echo "<script>alert('Error occured while adding Catering services !')</script>";
					echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
				}
			} catch (Exception $e) {
				$e->getMessage();
			}
		}
		
	}
	public function FetchCateringservices()
	{
		$fthr=$this->icon->query("SELECT * FROM employees_tb WHERE role='Cateringservices' ORDER BY employee_id DESC");
		?>
		<div style="height: 500px; overflow: auto; text-transform: capitalize;">
			<table class="table table-striped table-bordered table-responsive table-hover small">
				<tr>
					<th>Names</th>
					<th>Gender</th>
					<th>Qualifications</th>
					<th>Experience</th>
					<th>Specialisation</th>
					<th>Category</th>
					<th>Contact</th>
					<th>Documents</th>
					<th>Edit / Del</th>
				</tr>
			
			<?php
			foreach($fthr as $row) {
				$employee_id=$row['employee_id'];
				$document=$row['document'];
				echo "<tr>";
				echo "<td>".$row['names']."</td>";
				echo "<td>".$row['gender'];
				if ($row['status']==date("d/m/Y")) {
					echo "&nbsp<i style='font-size: 11px; background-color: #ff0000; color:#fff; padding: 1px;'>new</i>";
				}
				echo "</td>";
				echo "<td>".$row['qualification']."</td>";
				echo "<td>".$row['experience']."</td>";				
				echo "<td>".$row['specialisation']."</td>";
				echo "<td>".$row['category']."</td>";
				echo "<td>".$row['telephone']."</td>";
				echo "<td><a href='includes/downloaddocument.php?download=".$document."' class='btn btn-xs btn-success br-radius-zero'><i class='fa fa-download'>&nbsp</i>Downoad</a></td>";
				echo "<td style='padding-right: 0px;' margin-right: 0px;>
						<a href='#editemp".$employee_id."' class='btn btn-xs btn-primary' data-toggle='modal'><i class='fa fa-edit'>&nbsp</i></a>
						<a href='includes/deleteemp.php?employee_id=".$employee_id."' class='btn btn-xs btn-danger' onclick='return Comfirm();')><i class='fa fa-trash-o'>&nbsp</i></a>

						</td>";
				echo "</tr>";
				include 'includes/editemp.php';
			}
			?>
			</table>
		</div>
		<?php	
		
	}

	public function AddTourguidesQuery($names,$gender,$qualification,$experience,$specialisation,$category,$telephone,$document)
	{
		$chex=$this->icon->query("SELECT * FROM employees_tb SET WHERE telephone='$telephone'");
		$num=$chex->num_rows;
		if ($num==1) {
			echo "<script>alert('Employee already exists !')</script>";
			echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
		}
		else{
			$tempname=$_FILES['document']['tmp_name'];
	        $orignalname=$_FILES['document']['name'];
	        $size=($_FILES['document']['size']/5242880)."MB <br>";
	        $type=$_FILES['document']['type'];
	        $document=$_FILES['document']['name'];
	        move_uploaded_file($_FILES['document']['tmp_name'],"docs/documents/".$_FILES["document"]["name"]);
			$addhr=$this->icon->query("INSERT INTO employees_tb SET names='$names',gender='$gender',role='Tourguides',qualification='$qualification',experience='$experience',specialisation='$specialisation',category='$category',telephone='$telephone',document='$document',status='".date("d/m/Y")."' ");
			try {
				if ($addhr) {
					echo "<script>alert('Tour guides has been added !')</script>";
					echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
				}
				else{
					echo "<script>alert('Error occured while adding Tour guides !')</script>";
					echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
				}
			} catch (Exception $e) {
				$e->getMessage();
			}
		}
		
	}
	public function FetchTourguides()
	{
		$fthr=$this->icon->query("SELECT * FROM employees_tb WHERE role='Tourguides' ORDER BY employee_id DESC");
		?>
		<div style="height: 500px; overflow: auto; text-transform: capitalize;">
			<table class="table table-striped table-bordered table-responsive table-hover small">
				<tr>
					<th>Names</th>
					<th>Gender</th>
					<th>Qualifications</th>
					<th>Experience</th>
					<th>Specialisation</th>
					<th>Category</th>
					<th>Contact</th>
					<th>Documents</th>
					<th>Edit / Del</th>
				</tr>
			
			<?php
			foreach($fthr as $row) {
				$employee_id=$row['employee_id'];
				$document=$row['document'];
				echo "<tr>";
				echo "<td>".$row['names']."</td>";
				echo "<td>".$row['gender'];
				if ($row['status']==date("d/m/Y")) {
					echo "&nbsp<i style='font-size: 11px; background-color: #ff0000; color:#fff; padding: 1px;'>new</i>";
				}
				echo "</td>";
				echo "<td>".$row['qualification']."</td>";
				echo "<td>".$row['experience']."</td>";				
				echo "<td>".$row['specialisation']."</td>";
				echo "<td>".$row['category']."</td>";
				echo "<td>".$row['telephone']."</td>";
				echo "<td><a href='includes/downloaddocument.php?download=".$document."' class='btn btn-xs btn-success br-radius-zero'><i class='fa fa-download'>&nbsp</i>Downoad</a></td>";
				echo "<td style='padding-right: 0px;' margin-right: 0px;>
						<a href='#editemp".$employee_id."' class='btn btn-xs btn-primary' data-toggle='modal'><i class='fa fa-edit'>&nbsp</i></a>
						<a href='includes/deleteemp.php?employee_id=".$employee_id."' class='btn btn-xs btn-danger' onclick='return Comfirm();')><i class='fa fa-trash-o'>&nbsp</i></a>

						</td>";
				echo "</tr>";
				include 'includes/editemp.php';
			}
			?>
			</table>
		</div>
		<?php	
		
	}

	public function AddAspothersQuery($names,$gender,$qualification,$experience,$specialisation,$category,$telephone,$document)
	{
		$chex=$this->icon->query("SELECT * FROM employees_tb SET WHERE telephone='$telephone'");
		$num=$chex->num_rows;
		if ($num==1) {
			echo "<script>alert('Employee already exists !')</script>";
			echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
		}
		else{
			$tempname=$_FILES['document']['tmp_name'];
	        $orignalname=$_FILES['document']['name'];
	        $size=($_FILES['document']['size']/5242880)."MB <br>";
	        $type=$_FILES['document']['type'];
	        $document=$_FILES['document']['name'];
	        move_uploaded_file($_FILES['document']['tmp_name'],"docs/documents/".$_FILES["document"]["name"]);
			$addhr=$this->icon->query("INSERT INTO employees_tb SET names='$names',gender='$gender',role='Aspothers',qualification='$qualification',experience='$experience',specialisation='$specialisation',category='$category',telephone='$telephone',document='$document',status='".date("d/m/Y")."' ");
			try {
				if ($addhr) {
					echo "<script>alert('Others has been added !')</script>";
					echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
				}
				else{
					echo "<script>alert('Error occured while adding Others !')</script>";
					echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
				}
			} catch (Exception $e) {
				$e->getMessage();
			}
		}
		
	}
	public function FetchAspothers()
	{
		$fthr=$this->icon->query("SELECT * FROM employees_tb WHERE role='Aspothers' ORDER BY employee_id DESC");
		?>
		<div style="height: 500px; overflow: auto; text-transform: capitalize;">
			<table class="table table-striped table-bordered table-responsive table-hover small">
				<tr>
					<th>Names</th>
					<th>Gender</th>
					<th>Qualifications</th>
					<th>Experience</th>
					<th>Specialisation</th>
					<th>Category</th>
					<th>Contact</th>
					<th>Documents</th>
					<th>Edit / Del</th>
				</tr>
			
			<?php
			foreach($fthr as $row) {
				$employee_id=$row['employee_id'];
				$document=$row['document'];
				echo "<tr>";
				echo "<td>".$row['names']."</td>";
				echo "<td>".$row['gender'];
				if ($row['status']==date("d/m/Y")) {
					echo "&nbsp<i style='font-size: 11px; background-color: #ff0000; color:#fff; padding: 1px;'>new</i>";
				}
				echo "</td>";
				echo "<td>".$row['qualification']."</td>";
				echo "<td>".$row['experience']."</td>";				
				echo "<td>".$row['specialisation']."</td>";
				echo "<td>".$row['category']."</td>";
				echo "<td>".$row['telephone']."</td>";
				echo "<td><a href='includes/downloaddocument.php?download=".$document."' class='btn btn-xs btn-success br-radius-zero'><i class='fa fa-download'>&nbsp</i>Downoad</a></td>";
				echo "<td style='padding-right: 0px;' margin-right: 0px;>
						<a href='#editemp".$employee_id."' class='btn btn-xs btn-primary' data-toggle='modal'><i class='fa fa-edit'>&nbsp</i></a>
						<a href='includes/deleteemp.php?employee_id=".$employee_id."' class='btn btn-xs btn-danger' onclick='return Comfirm();')><i class='fa fa-trash-o'>&nbsp</i></a>

						</td>";
				echo "</tr>";
				include 'includes/editemp.php';
			}
			?>
			</table>
		</div>
		<?php	
		
	}

	public function AddDomestichelpersQuery($names,$gender,$qualification,$experience,$specialisation,$category,$telephone,$document)
	{
		$chex=$this->icon->query("SELECT * FROM employees_tb SET WHERE telephone='$telephone'");
		$num=$chex->num_rows;
		if ($num==1) {
			echo "<script>alert('Employee already exists !')</script>";
			echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
		}
		else{
			$tempname=$_FILES['document']['tmp_name'];
	        $orignalname=$_FILES['document']['name'];
	        $size=($_FILES['document']['size']/5242880)."MB <br>";
	        $type=$_FILES['document']['type'];
	        $document=$_FILES['document']['name'];
	        move_uploaded_file($_FILES['document']['tmp_name'],"docs/documents/".$_FILES["document"]["name"]);
			$addhr=$this->icon->query("INSERT INTO employees_tb SET names='$names',gender='$gender',role='Domestichelpers',qualification='$qualification',experience='$experience',specialisation='$specialisation',category='$category',telephone='$telephone',document='$document',status='".date("d/m/Y")."' ");
			try {
				if ($addhr) {
					echo "<script>alert('Domestic helpers has been added !')</script>";
					echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
				}
				else{
					echo "<script>alert('Error occured while adding Domestic helpers !')</script>";
					echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
				}
			} catch (Exception $e) {
				$e->getMessage();
			}
		}
		
	}
	public function FetchDomestichelpers()
	{
		$fthr=$this->icon->query("SELECT * FROM employees_tb WHERE role='Domestichelpers' ORDER BY employee_id DESC");
		?>
		<div style="height: 500px; overflow: auto; text-transform: capitalize;">
			<table class="table table-striped table-bordered table-responsive table-hover small">
				<tr>
					<th>Names</th>
					<th>Gender</th>
					<th>Qualifications</th>
					<th>Experience</th>
					<th>Specialisation</th>
					<th>Category</th>
					<th>Contact</th>
					<th>Documents</th>
					<th>Edit / Del</th>
				</tr>
			
			<?php
			foreach($fthr as $row) {
				$employee_id=$row['employee_id'];
				$document=$row['document'];
				echo "<tr>";
				echo "<td>".$row['names']."</td>";
				echo "<td>".$row['gender'];
				if ($row['status']==date("d/m/Y")) {
					echo "&nbsp<i style='font-size: 11px; background-color: #ff0000; color:#fff; padding: 1px;'>new</i>";
				}
				echo "</td>";
				echo "<td>".$row['qualification']."</td>";
				echo "<td>".$row['experience']."</td>";				
				echo "<td>".$row['specialisation']."</td>";
				echo "<td>".$row['category']."</td>";
				echo "<td>".$row['telephone']."</td>";
				echo "<td><a href='includes/downloaddocument.php?download=".$document."' class='btn btn-xs btn-success br-radius-zero'><i class='fa fa-download'>&nbsp</i>Downoad</a></td>";
				echo "<td style='padding-right: 0px;' margin-right: 0px;>
						<a href='#editemp".$employee_id."' class='btn btn-xs btn-primary' data-toggle='modal'><i class='fa fa-edit'>&nbsp</i></a>
						<a href='includes/deleteemp.php?employee_id=".$employee_id."' class='btn btn-xs btn-danger' onclick='return Comfirm();')><i class='fa fa-trash-o'>&nbsp</i></a>

						</td>";
				echo "</tr>";
				include 'includes/editemp.php';
			}
			?>
			</table>
		</div>
		<?php	
		
	}

	public function AddCleanersQuery($names,$gender,$qualification,$experience,$specialisation,$category,$telephone,$document)
	{
		$chex=$this->icon->query("SELECT * FROM employees_tb SET WHERE telephone='$telephone'");
		$num=$chex->num_rows;
		if ($num==1) {
			echo "<script>alert('Employee already exists !')</script>";
			echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
		}
		else{
			$tempname=$_FILES['document']['tmp_name'];
	        $orignalname=$_FILES['document']['name'];
	        $size=($_FILES['document']['size']/5242880)."MB <br>";
	        $type=$_FILES['document']['type'];
	        $document=$_FILES['document']['name'];
	        move_uploaded_file($_FILES['document']['tmp_name'],"docs/documents/".$_FILES["document"]["name"]);
			$addhr=$this->icon->query("INSERT INTO employees_tb SET names='$names',gender='$gender',role='Cleaners',qualification='$qualification',experience='$experience',specialisation='$specialisation',category='$category',telephone='$telephone',document='$document',status='".date("d/m/Y")."' ");
			try {
				if ($addhr) {
					echo "<script>alert('Cleaners has been added !')</script>";
					echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
				}
				else{
					echo "<script>alert('Error occured while adding Cleaners !')</script>";
					echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
				}
			} catch (Exception $e) {
				$e->getMessage();
			}
		}
		
	}
	public function FetchCleaners()
	{
		$fthr=$this->icon->query("SELECT * FROM employees_tb WHERE role='Cleaners' ORDER BY employee_id DESC");
		?>
		<div style="height: 500px; overflow: auto; text-transform: capitalize;">
			<table class="table table-striped table-bordered table-responsive table-hover small">
				<tr>
					<th>Names</th>
					<th>Gender</th>
					<th>Qualifications</th>
					<th>Experience</th>
					<th>Specialisation</th>
					<th>Category</th>
					<th>Contact</th>
					<th>Documents</th>
					<th>Edit / Del</th>
				</tr>
			
			<?php
			foreach($fthr as $row) {
				$employee_id=$row['employee_id'];
				$document=$row['document'];
				echo "<tr>";
				echo "<td>".$row['names']."</td>";
				echo "<td>".$row['gender'];
				if ($row['status']==date("d/m/Y")) {
					echo "&nbsp<i style='font-size: 11px; background-color: #ff0000; color:#fff; padding: 1px;'>new</i>";
				}
				echo "</td>";
				echo "<td>".$row['qualification']."</td>";
				echo "<td>".$row['experience']."</td>";				
				echo "<td>".$row['specialisation']."</td>";
				echo "<td>".$row['category']."</td>";
				echo "<td>".$row['telephone']."</td>";
				echo "<td><a href='includes/downloaddocument.php?download=".$document."' class='btn btn-xs btn-success br-radius-zero'><i class='fa fa-download'>&nbsp</i>Downoad</a></td>";
				echo "<td style='padding-right: 0px;' margin-right: 0px;>
						<a href='#editemp".$employee_id."' class='btn btn-xs btn-primary' data-toggle='modal'><i class='fa fa-edit'>&nbsp</i></a>
						<a href='includes/deleteemp.php?employee_id=".$employee_id."' class='btn btn-xs btn-danger' onclick='return Comfirm();')><i class='fa fa-trash-o'>&nbsp</i></a>

						</td>";
				echo "</tr>";
				include 'includes/editemp.php';
			}
			?>
			</table>
		</div>
		<?php	
		
	}

	public function AddOperationalworkersQuery($names,$gender,$qualification,$experience,$specialisation,$category,$telephone,$document)
	{
		$chex=$this->icon->query("SELECT * FROM employees_tb SET WHERE telephone='$telephone'");
		$num=$chex->num_rows;
		if ($num==1) {
			echo "<script>alert('Employee already exists !')</script>";
			echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
		}
		else{
			$tempname=$_FILES['document']['tmp_name'];
	        $orignalname=$_FILES['document']['name'];
	        $size=($_FILES['document']['size']/5242880)."MB <br>";
	        $type=$_FILES['document']['type'];
	        $document=$_FILES['document']['name'];
	        move_uploaded_file($_FILES['document']['tmp_name'],"docs/documents/".$_FILES["document"]["name"]);
			$addhr=$this->icon->query("INSERT INTO employees_tb SET names='$names',gender='$gender',role='Operationalworkers',qualification='$qualification',experience='$experience',specialisation='$specialisation',category='$category',telephone='$telephone',document='$document',status='".date("d/m/Y")."' ");
			try {
				if ($addhr) {
					echo "<script>alert('Operational workers has been added !')</script>";
					echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
				}
				else{
					echo "<script>alert('Error occured while adding Operational workers !')</script>";
					echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
				}
			} catch (Exception $e) {
				$e->getMessage();
			}
		}
		
	}
	public function FetchOperationalworkers()
	{
		$fthr=$this->icon->query("SELECT * FROM employees_tb WHERE role='Operationalworkers' ORDER BY employee_id DESC");
		?>
		<div style="height: 500px; overflow: auto; text-transform: capitalize;">
			<table class="table table-striped table-bordered table-responsive table-hover small">
				<tr>
					<th>Names</th>
					<th>Gender</th>
					<th>Qualifications</th>
					<th>Experience</th>
					<th>Specialisation</th>
					<th>Category</th>
					<th>Contact</th>
					<th>Documents</th>
					<th>Edit / Del</th>
				</tr>
			
			<?php
			foreach($fthr as $row) {
				$employee_id=$row['employee_id'];
				$document=$row['document'];
				echo "<tr>";
				echo "<td>".$row['names']."</td>";
				echo "<td>".$row['gender'];
				if ($row['status']==date("d/m/Y")) {
					echo "&nbsp<i style='font-size: 11px; background-color: #ff0000; color:#fff; padding: 1px;'>new</i>";
				}
				echo "</td>";
				echo "<td>".$row['qualification']."</td>";
				echo "<td>".$row['experience']."</td>";				
				echo "<td>".$row['specialisation']."</td>";
				echo "<td>".$row['category']."</td>";
				echo "<td>".$row['telephone']."</td>";
				echo "<td><a href='includes/downloaddocument.php?download=".$document."' class='btn btn-xs btn-success br-radius-zero'><i class='fa fa-download'>&nbsp</i>Downoad</a></td>";
				echo "<td style='padding-right: 0px;' margin-right: 0px;>
						<a href='#editemp".$employee_id."' class='btn btn-xs btn-primary' data-toggle='modal'><i class='fa fa-edit'>&nbsp</i></a>
						<a href='includes/deleteemp.php?employee_id=".$employee_id."' class='btn btn-xs btn-danger' onclick='return Comfirm();')><i class='fa fa-trash-o'>&nbsp</i></a>

						</td>";
				echo "</tr>";
				include 'includes/editemp.php';
			}
			?>
			</table>
		</div>
		<?php	
		
	}

	public function AddOthersQuery($names,$gender,$qualification,$experience,$specialisation,$category,$telephone,$document)
	{
		$chex=$this->icon->query("SELECT * FROM employees_tb SET WHERE telephone='$telephone'");
		$num=$chex->num_rows;
		if ($num==1) {
			echo "<script>alert('Employee already exists !')</script>";
			echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
		}
		else{
			$tempname=$_FILES['document']['tmp_name'];
	        $orignalname=$_FILES['document']['name'];
	        $size=($_FILES['document']['size']/5242880)."MB <br>";
	        $type=$_FILES['document']['type'];
	        $document=$_FILES['document']['name'];
	        move_uploaded_file($_FILES['document']['tmp_name'],"docs/documents/".$_FILES["document"]["name"]);
			$addhr=$this->icon->query("INSERT INTO employees_tb SET names='$names',gender='$gender',role='Others',qualification='$qualification',experience='$experience',specialisation='$specialisation',category='$category',telephone='$telephone',document='$document',status='".date("d/m/Y")."' ");
			try {
				if ($addhr) {
					echo "<script>alert('Others has been added !')</script>";
					echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
				}
				else{
					echo "<script>alert('Error occured while adding Others !')</script>";
					echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
				}
			} catch (Exception $e) {
				$e->getMessage();
			}
		}
		
	}
	public function FetchOthers()
	{
		$fthr=$this->icon->query("SELECT * FROM employees_tb WHERE role='Others' ORDER BY employee_id DESC");
		?>
		<div style="height: 500px; overflow: auto; text-transform: capitalize;">
			<table class="table table-striped table-bordered table-responsive table-hover small">
				<tr>
					<th>Names</th>
					<th>Gender</th>
					<th>Qualifications</th>
					<th>Experience</th>
					<th>Specialisation</th>
					<th>Category</th>
					<th>Contact</th>
					<th>Documents</th>
					<th>Edit / Del</th>
				</tr>
			
			<?php
			foreach($fthr as $row) {
				$employee_id=$row['employee_id'];
				$document=$row['document'];
				echo "<tr>";
				echo "<td>".$row['names']."</td>";
				echo "<td>".$row['gender'];
				if ($row['status']==date("d/m/Y")) {
					echo "&nbsp<i style='font-size: 11px; background-color: #ff0000; color:#fff; padding: 1px;'>new</i>";
				}
				echo "</td>";
				echo "<td>".$row['qualification']."</td>";
				echo "<td>".$row['experience']."</td>";				
				echo "<td>".$row['specialisation']."</td>";
				echo "<td>".$row['category']."</td>";
				echo "<td>".$row['telephone']."</td>";
				echo "<td><a href='includes/downloaddocument.php?download=".$document."' class='btn btn-xs btn-success br-radius-zero'><i class='fa fa-download'>&nbsp</i>Downoad</a></td>";
				echo "<td style='padding-right: 0px;' margin-right: 0px;>
						<a href='#editemp".$employee_id."' class='btn btn-xs btn-primary' data-toggle='modal'><i class='fa fa-edit'>&nbsp</i></a>
						<a href='includes/deleteemp.php?employee_id=".$employee_id."' class='btn btn-xs btn-danger' onclick='return Comfirm();')><i class='fa fa-trash-o'>&nbsp</i></a>

						</td>";
				echo "</tr>";
				include 'includes/editemp.php';
			}
			?>
			</table>
		</div>
		<?php	
		
	}
	
}
$ico = new Core();
?>