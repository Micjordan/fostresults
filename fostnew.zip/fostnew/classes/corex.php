<?php

class Corex extends Config
{

	public function UcpasswordQuery($username,$oldpassword,$newpassword)
	{
		$chs=$this->icon->query("SELECT * FROM users_tb WHERE username='$username'");
		$rq=$chs->fetch_array();

		if (strlen($oldpassword)<5) {
			echo "<script>alert('Dear ".$username. "Password length should be five characters and above')</script>";
			echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
		}
		else if (strlen($newpassword)<5) {
			echo "<script>alert('Dear ".$username. "New password length should be five characters and above')</script>";
			echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
		}
		else if (strlen($oldpassword)>5 && strlen($newpassword)>5 && $rq['password']!=sha1(md5($oldpassword))) {
			echo "<script>alert('Old password is wrong because there is no  match found in our database')</script>";
			echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
		}
		else{                   
			$password=sha1(md5($newpassword));
			$qu=$this->icon->query("UPDATE users_tb SET password='$password' WHERE username='$username'");
			if ($qu) {
			echo "<script>alert('Password changed ".$username .".')</script>";
			echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
			}
			else{
			echo "<script>alert('Error......')</script>";
			echo "<script>window.open('".$_SERVER['HTTP_REFERER']."','_self')</script>";
			}
		} 
	}

	
	public function FetchHr()
	{
		$fthr=$this->icon->query("SELECT * FROM employees_tb WHERE role='HR' ORDER BY employee_id DESC");
		?>
		<div style="height: 500px; overflow: auto; text-transform: capitalize;">
			<table class="table table-striped table-bordered table-responsive table-hover small">
				<tr>
					<th>Names</th>
					<th>Gender</th>
					<th>Qualifications</th>
					<th>Experience</th>
					<th>Specialisation</th>
					<th>Category</th>
				</tr>
			
			<?php
			foreach($fthr as $row) {
				$employee_id=$row['employee_id'];
				$document=$row['document'];
				echo "<tr>";
				echo "<td>".$row['names']."</td>";
				echo "<td>".$row['gender'];
				if ($row['status']==date("d/m/Y")) {
					echo "&nbsp<i style='font-size: 11px; background-color: #ff0000; color:#fff; padding: 2px;'>new</i>";
				}
				echo "</td>";
				echo "<td>".$row['qualification']."</td>";
				echo "<td>".$row['experience']."</td>";
				echo "<td>".$row['specialisation']."</td>";
				echo "<td>".$row['category']."</td>";
			}
			?>
			</table>
		</div>
		<?php	
		
	}

	public function HrnumQuery()
	{
		$hrnum=$this->icon->query("SELECT * FROM employees_tb WHERE role='HR'");
		echo $un=$hrnum->num_rows;
	}

	
	public function FetchAccountants()
	{
		$fthr=$this->icon->query("SELECT * FROM employees_tb WHERE role='Accountant' ORDER BY employee_id DESC");
		?>
		<div style="height: 500px; overflow: auto; text-transform: capitalize;">
			<table class="table table-striped table-bordered table-responsive table-hover small">
				<tr>
					<th>Names</th>
					<th>Gender</th>
					<th>Qualifications</th>
					<th>Experience</th>
					<th>Specialisation</th>
					<th>Category</th>
				</tr>
			
			<?php
			foreach($fthr as $row) {
				$employee_id=$row['employee_id'];
				$document=$row['document'];
				echo "<tr>";
				echo "<td>".$row['names']."</td>";
				echo "<td>".$row['gender'];
				if ($row['status']==date("d/m/Y")) {
					echo "&nbsp<i style='font-size: 11px; background-color: #ff0000; color:#fff; padding: 2px;'>new</i>";
				}
				echo "</td>";
				echo "<td>".$row['qualification']."</td>";
				echo "<td>".$row['experience']."</td>";
				echo "<td>".$row['specialisation']."</td>";
				echo "<td>".$row['category']."</td>";
			}
			?>
			</table>
		</div>
		<?php	
		
	}

	
	public function FetchAuditor()
	{
		$fthr=$this->icon->query("SELECT * FROM employees_tb WHERE role='Auditor' ORDER BY employee_id DESC");
		?>
		<div style="height: 500px; overflow: auto; text-transform: capitalize;">
			<table class="table table-striped table-bordered table-responsive table-hover small">
				<tr>
					<th>Names</th>
					<th>Gender</th>
					<th>Qualifications</th>
					<th>Experience</th>
					<th>Specialisation</th>
					<th>Category</th>
				</tr>
			
			<?php
			foreach($fthr as $row) {
				$employee_id=$row['employee_id'];
				$document=$row['document'];
				echo "<tr>";
				echo "<td>".$row['names']."</td>";
				echo "<td>".$row['gender'];
				if ($row['status']==date("d/m/Y")) {
					echo "&nbsp<i style='font-size: 11px; background-color: #ff0000; color:#fff; padding: 2px;'>new</i>";
				}
				echo "</td>";
				echo "<td>".$row['qualification']."</td>";
				echo "<td>".$row['experience']."</td>";
				echo "<td>".$row['specialisation']."</td>";
				echo "<td>".$row['category']."</td>";
			}
			?>
			</table>
		</div>
		<?php	
		
	}

	
	public function FetchAdministrator()
	{
		$fthr=$this->icon->query("SELECT * FROM employees_tb WHERE role='Administrator' ORDER BY employee_id DESC");
		?>
		<div style="height: 500px; overflow: auto; text-transform: capitalize;">
			<table class="table table-striped table-bordered table-responsive table-hover small">
				<tr>
					<th>Names</th>
					<th>Gender</th>
					<th>Qualifications</th>
					<th>Experience</th>
					<th>Specialisation</th>
					<th>Category</th>
				</tr>
			
			<?php
			foreach($fthr as $row) {
				$employee_id=$row['employee_id'];
				$document=$row['document'];
				echo "<tr>";
				echo "<td>".$row['names']."</td>";
				echo "<td>".$row['gender'];
				if ($row['status']==date("d/m/Y")) {
					echo "&nbsp<i style='font-size: 11px; background-color: #ff0000; color:#fff; padding: 2px;'>new</i>";
				}
				echo "</td>";
				echo "<td>".$row['qualification']."</td>";
				echo "<td>".$row['experience']."</td>";
				echo "<td>".$row['specialisation']."</td>";
				echo "<td>".$row['category']."</td>";
			}
			?>
			</table>
		</div>
		<?php	
		
	}

	public function FetchEngineer()
	{
		$fthr=$this->icon->query("SELECT * FROM employees_tb WHERE role='Engineer' ORDER BY employee_id DESC");
		?>
		<div style="height: 500px; overflow: auto; text-transform: capitalize;">
			<table class="table table-striped table-bordered table-responsive table-hover small">
				<tr>
					<th>Names</th>
					<th>Gender</th>
					<th>Qualifications</th>
					<th>Experience</th>
					<th>Specialisation</th>
					<th>Category</th>
				</tr>
			
			<?php
			foreach($fthr as $row) {
				$employee_id=$row['employee_id'];
				$document=$row['document'];
				echo "<tr>";
				echo "<td>".$row['names']."</td>";
				echo "<td>".$row['gender'];
				if ($row['status']==date("d/m/Y")) {
					echo "&nbsp<i style='font-size: 11px; background-color: #ff0000; color:#fff; padding: 2px;'>new</i>";
				}
				echo "</td>";
				echo "<td>".$row['qualification']."</td>";
				echo "<td>".$row['experience']."</td>";
				echo "<td>".$row['specialisation']."</td>";
				echo "<td>".$row['category']."</td>";
			}
			?>
			</table>
		</div>
		<?php	
		
	}

	
	public function FetchIt()
	{
		$fthr=$this->icon->query("SELECT * FROM employees_tb WHERE role='It' ORDER BY employee_id DESC");
		?>
		<div style="height: 500px; overflow: auto; text-transform: capitalize;">
			<table class="table table-striped table-bordered table-responsive table-hover small">
				<tr>
					<th>Names</th>
					<th>Gender</th>
					<th>Qualifications</th>
					<th>Experience</th>
					<th>Specialisation</th>
					<th>Category</th>
				</tr>
			
			<?php
			foreach($fthr as $row) {
				$employee_id=$row['employee_id'];
				$document=$row['document'];
				echo "<tr>";
				echo "<td>".$row['names']."</td>";
				echo "<td>".$row['gender'];
				if ($row['status']==date("d/m/Y")) {
					echo "&nbsp<i style='font-size: 11px; background-color: #ff0000; color:#fff; padding: 2px;'>new</i>";
				}
				echo "</td>";
				echo "<td>".$row['qualification']."</td>";
				echo "<td>".$row['experience']."</td>";
				echo "<td>".$row['specialisation']."</td>";
				echo "<td>".$row['category']."</td>";
			}
			?>
			</table>
		</div>
		<?php	
		
	}

	
	public function FetchMedicalworker()
	{
		$fthr=$this->icon->query("SELECT * FROM employees_tb WHERE role='Medicalworker' ORDER BY employee_id DESC");
		?>
		<div style="height: 500px; overflow: auto; text-transform: capitalize;">
			<table class="table table-striped table-bordered table-responsive table-hover small">
				<tr>
					<th>Names</th>
					<th>Gender</th>
					<th>Qualifications</th>
					<th>Experience</th>
					<th>Specialisation</th>
					<th>Category</th>
				</tr>
			
			<?php
			foreach($fthr as $row) {
				$employee_id=$row['employee_id'];
				$document=$row['document'];
				echo "<tr>";
				echo "<td>".$row['names']."</td>";
				echo "<td>".$row['gender'];
				if ($row['status']==date("d/m/Y")) {
					echo "&nbsp<i style='font-size: 11px; background-color: #ff0000; color:#fff; padding: 2px;'>new</i>";
				}
				echo "</td>";
				echo "<td>".$row['qualification']."</td>";
				echo "<td>".$row['experience']."</td>";
				echo "<td>".$row['specialisation']."</td>";
				echo "<td>".$row['category']."</td>";
			}
			?>
			</table>
		</div>
		<?php	
		
	}

	
	public function FetchFinacialmanager()
	{
		$fthr=$this->icon->query("SELECT * FROM employees_tb WHERE role='Finacialmanager' ORDER BY employee_id DESC");
		?>
		<div style="height: 500px; overflow: auto; text-transform: capitalize;">
			<table class="table table-striped table-bordered table-responsive table-hover small">
				<tr>
					<th>Names</th>
					<th>Gender</th>
					<th>Qualifications</th>
					<th>Experience</th>
					<th>Specialisation</th>
					<th>Category</th>
				</tr>
			
			<?php
			foreach($fthr as $row) {
				$employee_id=$row['employee_id'];
				$document=$row['document'];
				echo "<tr>";
				echo "<td>".$row['names']."</td>";
				echo "<td>".$row['gender'];
				if ($row['status']==date("d/m/Y")) {
					echo "&nbsp<i style='font-size: 11px; background-color: #ff0000; color:#fff; padding: 2px;'>new</i>";
				}
				echo "</td>";
				echo "<td>".$row['qualification']."</td>";
				echo "<td>".$row['experience']."</td>";
				echo "<td>".$row['specialisation']."</td>";
				echo "<td>".$row['category']."</td>";
			}
			?>
			</table>
		</div>
		<?php	
		
	}

	
	public function FetchExecutivemanager()
	{
		$fthr=$this->icon->query("SELECT * FROM employees_tb WHERE role='Executivemanager' ORDER BY employee_id DESC");
		?>
		<div style="height: 500px; overflow: auto; text-transform: capitalize;">
			<table class="table table-striped table-bordered table-responsive table-hover small">
				<tr>
					<th>Names</th>
					<th>Gender</th>
					<th>Qualifications</th>
					<th>Experience</th>
					<th>Specialisation</th>
					<th>Category</th>
				</tr>
			
			<?php
			foreach($fthr as $row) {
				$employee_id=$row['employee_id'];
				$document=$row['document'];
				echo "<tr>";
				echo "<td>".$row['names']."</td>";
				echo "<td>".$row['gender'];
				if ($row['status']==date("d/m/Y")) {
					echo "&nbsp<i style='font-size: 11px; background-color: #ff0000; color:#fff; padding: 2px;'>new</i>";
				}
				echo "</td>";
				echo "<td>".$row['qualification']."</td>";
				echo "<td>".$row['experience']."</td>";
				echo "<td>".$row['specialisation']."</td>";
				echo "<td>".$row['category']."</td>";
			}
			?>
			</table>
		</div>
		<?php	
		
	}

	public function FetchLegalrepresentative()
	{
		$fthr=$this->icon->query("SELECT * FROM employees_tb WHERE role='Legalrepresentative' ORDER BY employee_id DESC");
		?>
		<div style="height: 500px; overflow: auto; text-transform: capitalize;">
			<table class="table table-striped table-bordered table-responsive table-hover small">
				<tr>
					<th>Names</th>
					<th>Gender</th>
					<th>Qualifications</th>
					<th>Experience</th>
					<th>Specialisation</th>
					<th>Category</th>
				</tr>
			
			<?php
			foreach($fthr as $row) {
				$employee_id=$row['employee_id'];
				$document=$row['document'];
				echo "<tr>";
				echo "<td>".$row['names']."</td>";
				echo "<td>".$row['gender'];
				if ($row['status']==date("d/m/Y")) {
					echo "&nbsp<i style='font-size: 11px; background-color: #ff0000; color:#fff; padding: 2px;'>new</i>";
				}
				echo "</td>";
				echo "<td>".$row['qualification']."</td>";
				echo "<td>".$row['experience']."</td>";
				echo "<td>".$row['specialisation']."</td>";
				echo "<td>".$row['category']."</td>";
			}
			?>
			</table>
		</div>
		<?php	
		
	}

	public function FetchMarketingmanager()
	{
		$fthr=$this->icon->query("SELECT * FROM employees_tb WHERE role='Marketingmanager' ORDER BY employee_id DESC");
		?>
		<div style="height: 500px; overflow: auto; text-transform: capitalize;">
			<table class="table table-striped table-bordered table-responsive table-hover small">
				<tr>
					<th>Names</th>
					<th>Gender</th>
					<th>Qualifications</th>
					<th>Experience</th>
					<th>Specialisation</th>
					<th>Category</th>
				</tr>
			
			<?php
			foreach($fthr as $row) {
				$employee_id=$row['employee_id'];
				$document=$row['document'];
				echo "<tr>";
				echo "<td>".$row['names']."</td>";
				echo "<td>".$row['gender'];
				if ($row['status']==date("d/m/Y")) {
					echo "&nbsp<i style='font-size: 11px; background-color: #ff0000; color:#fff; padding: 2px;'>new</i>";
				}
				echo "</td>";
				echo "<td>".$row['qualification']."</td>";
				echo "<td>".$row['experience']."</td>";
				echo "<td>".$row['specialisation']."</td>";
				echo "<td>".$row['category']."</td>";
			}
			?>
			</table>
		</div>
		<?php	
		
	}
public function FetchTeachers()
	{
		$fthr=$this->icon->query("SELECT * FROM employees_tb WHERE role='Teachers' ORDER BY employee_id DESC");
		?>
		<div style="height: 500px; overflow: auto; text-transform: capitalize;">
			<table class="table table-striped table-bordered table-responsive table-hover small">
				<tr>
					<th>Names</th>
					<th>Gender</th>
					<th>Qualifications</th>
					<th>Experience</th>
					<th>Specialisation</th>
					<th>Category</th>
				</tr>
			
			<?php
			foreach($fthr as $row) {
				$employee_id=$row['employee_id'];
				$document=$row['document'];
				echo "<tr>";
				echo "<td>".$row['names']."</td>";
				echo "<td>".$row['gender'];
				if ($row['status']==date("d/m/Y")) {
					echo "&nbsp<i style='font-size: 11px; background-color: #ff0000; color:#fff; padding: 2px;'>new</i>";
				}
				echo "</td>";
				echo "<td>".$row['qualification']."</td>";
				echo "<td>".$row['experience']."</td>";
				echo "<td>".$row['specialisation']."</td>";
				echo "<td>".$row['category']."</td>";
			}
			?>
			</table>
		</div>
		<?php	
		
	}

	public function FetchPainters()
	{
		$fthr=$this->icon->query("SELECT * FROM employees_tb WHERE role='Painters' ORDER BY employee_id DESC");
		?>
		<div style="height: 500px; overflow: auto; text-transform: capitalize;">
			<table class="table table-striped table-bordered table-responsive table-hover small">
				<tr>
					<th>Names</th>
					<th>Gender</th>
					<th>Qualifications</th>
					<th>Experience</th>
					<th>Specialisation</th>
					<th>Category</th>
				</tr>
			
			<?php
			foreach($fthr as $row) {
				$employee_id=$row['employee_id'];
				$document=$row['document'];
				echo "<tr>";
				echo "<td>".$row['names']."</td>";
				echo "<td>".$row['gender'];
				if ($row['status']==date("d/m/Y")) {
					echo "&nbsp<i style='font-size: 11px; background-color: #ff0000; color:#fff; padding: 2px;'>new</i>";
				}
				echo "</td>";
				echo "<td>".$row['qualification']."</td>";
				echo "<td>".$row['experience']."</td>";
				echo "<td>".$row['specialisation']."</td>";
				echo "<td>".$row['category']."</td>";
			}
			?>
			</table>
		</div>
		<?php	
		
	}

	public function FetchReceptionists()
	{
		$fthr=$this->icon->query("SELECT * FROM employees_tb WHERE role='Receptionists' ORDER BY employee_id DESC");
		?>
		<div style="height: 500px; overflow: auto; text-transform: capitalize;">
			<table class="table table-striped table-bordered table-responsive table-hover small">
				<tr>
					<th>Names</th>
					<th>Gender</th>
					<th>Qualifications</th>
					<th>Experience</th>
					<th>Specialisation</th>
					<th>Category</th>
				</tr>
			
			<?php
			foreach($fthr as $row) {
				$employee_id=$row['employee_id'];
				$document=$row['document'];
				echo "<tr>";
				echo "<td>".$row['names']."</td>";
				echo "<td>".$row['gender'];
				if ($row['status']==date("d/m/Y")) {
					echo "&nbsp<i style='font-size: 11px; background-color: #ff0000; color:#fff; padding: 2px;'>new</i>";
				}
				echo "</td>";
				echo "<td>".$row['qualification']."</td>";
				echo "<td>".$row['experience']."</td>";
				echo "<td>".$row['specialisation']."</td>";
				echo "<td>".$row['category']."</td>";
			}
			?>
			</table>
		</div>
		<?php	
		
	}

	public function FetchDrivers()
	{
		$fthr=$this->icon->query("SELECT * FROM employees_tb WHERE role='Drivers' ORDER BY employee_id DESC");
		?>
		<div style="height: 500px; overflow: auto; text-transform: capitalize;">
			<table class="table table-striped table-bordered table-responsive table-hover small">
				<tr>
					<th>Names</th>
					<th>Gender</th>
					<th>Qualifications</th>
					<th>Experience</th>
					<th>Specialisation</th>
					<th>Category</th>
				</tr>
			
			<?php
			foreach($fthr as $row) {
				$employee_id=$row['employee_id'];
				$document=$row['document'];
				echo "<tr>";
				echo "<td>".$row['names']."</td>";
				echo "<td>".$row['gender'];
				if ($row['status']==date("d/m/Y")) {
					echo "&nbsp<i style='font-size: 11px; background-color: #ff0000; color:#fff; padding: 2px;'>new</i>";
				}
				echo "</td>";
				echo "<td>".$row['qualification']."</td>";
				echo "<td>".$row['experience']."</td>";
				echo "<td>".$row['specialisation']."</td>";
				echo "<td>".$row['category']."</td>";
			}
			?>
			</table>
		</div>
		<?php	
		
	}


	public function FetchSecurityguards()
	{
		$fthr=$this->icon->query("SELECT * FROM employees_tb WHERE role='Securityguards' ORDER BY employee_id DESC");
		?>
		<div style="height: 500px; overflow: auto; text-transform: capitalize;">
			<table class="table table-striped table-bordered table-responsive table-hover small">
				<tr>
					<th>Names</th>
					<th>Gender</th>
					<th>Qualifications</th>
					<th>Experience</th>
					<th>Specialisation</th>
					<th>Category</th>
				</tr>
			
			<?php
			foreach($fthr as $row) {
				$employee_id=$row['employee_id'];
				$document=$row['document'];
				echo "<tr>";
				echo "<td>".$row['names']."</td>";
				echo "<td>".$row['gender'];
				if ($row['status']==date("d/m/Y")) {
					echo "&nbsp<i style='font-size: 11px; background-color: #ff0000; color:#fff; padding: 2px;'>new</i>";
				}
				echo "</td>";
				echo "<td>".$row['qualification']."</td>";
				echo "<td>".$row['experience']."</td>";
				echo "<td>".$row['specialisation']."</td>";
				echo "<td>".$row['category']."</td>";
			}
			?>
			</table>
		</div>
		<?php	
		
	}


	public function FetchDataenteries()
	{
		$fthr=$this->icon->query("SELECT * FROM employees_tb WHERE role='Dataenteries' ORDER BY employee_id DESC");
		?>
		<div style="height: 500px; overflow: auto; text-transform: capitalize;">
			<table class="table table-striped table-bordered table-responsive table-hover small">
				<tr>
					<th>Names</th>
					<th>Gender</th>
					<th>Qualifications</th>
					<th>Experience</th>
					<th>Specialisation</th>
					<th>Category</th>
				</tr>
			
			<?php
			foreach($fthr as $row) {
				$employee_id=$row['employee_id'];
				$document=$row['document'];
				echo "<tr>";
				echo "<td>".$row['names']."</td>";
				echo "<td>".$row['gender'];
				if ($row['status']==date("d/m/Y")) {
					echo "&nbsp<i style='font-size: 11px; background-color: #ff0000; color:#fff; padding: 2px;'>new</i>";
				}
				echo "</td>";
				echo "<td>".$row['qualification']."</td>";
				echo "<td>".$row['experience']."</td>";
				echo "<td>".$row['specialisation']."</td>";
				echo "<td>".$row['category']."</td>";
			}
			?>
			</table>
		</div>
		<?php	
		
	}

	public function FetchSecriteries()
	{
		$fthr=$this->icon->query("SELECT * FROM employees_tb WHERE role='Secriteries' ORDER BY employee_id DESC");
		?>
		<div style="height: 500px; overflow: auto; text-transform: capitalize;">
			<table class="table table-striped table-bordered table-responsive table-hover small">
				<tr>
					<th>Names</th>
					<th>Gender</th>
					<th>Qualifications</th>
					<th>Experience</th>
					<th>Specialisation</th>
					<th>Category</th>
				</tr>
			
			<?php
			foreach($fthr as $row) {
				$employee_id=$row['employee_id'];
				$document=$row['document'];
				echo "<tr>";
				echo "<td>".$row['names']."</td>";
				echo "<td>".$row['gender'];
				if ($row['status']==date("d/m/Y")) {
					echo "&nbsp<i style='font-size: 11px; background-color: #ff0000; color:#fff; padding: 2px;'>new</i>";
				}
				echo "</td>";
				echo "<td>".$row['qualification']."</td>";
				echo "<td>".$row['experience']."</td>";
				echo "<td>".$row['specialisation']."</td>";
				echo "<td>".$row['category']."</td>";
			}
			?>
			</table>
		</div>
		<?php	
		
	}

	
	public function FetchOfficeassistants()
	{
		$fthr=$this->icon->query("SELECT * FROM employees_tb WHERE role='Officeassistants' ORDER BY employee_id DESC");
		?>
		<div style="height: 500px; overflow: auto; text-transform: capitalize;">
			<table class="table table-striped table-bordered table-responsive table-hover small">
				<tr>
					<th>Names</th>
					<th>Gender</th>
					<th>Qualifications</th>
					<th>Experience</th>
					<th>Specialisation</th>
					<th>Category</th>
				</tr>
			
			<?php
			foreach($fthr as $row) {
				$employee_id=$row['employee_id'];
				$document=$row['document'];
				echo "<tr>";
				echo "<td>".$row['names']."</td>";
				echo "<td>".$row['gender'];
				if ($row['status']==date("d/m/Y")) {
					echo "&nbsp<i style='font-size: 11px; background-color: #ff0000; color:#fff; padding: 2px;'>new</i>";
				}
				echo "</td>";
				echo "<td>".$row['qualification']."</td>";
				echo "<td>".$row['experience']."</td>";
				echo "<td>".$row['specialisation']."</td>";
				echo "<td>".$row['category']."</td>";
			}
			?>
			</table>
		</div>
		<?php	
		
	}

	
	public function FetchSalespersonel()
	{
		$fthr=$this->icon->query("SELECT * FROM employees_tb WHERE role='Salespersonel' ORDER BY employee_id DESC");
		?>
		<div style="height: 500px; overflow: auto; text-transform: capitalize;">
			<table class="table table-striped table-bordered table-responsive table-hover small">
				<tr>
					<th>Names</th>
					<th>Gender</th>
					<th>Qualifications</th>
					<th>Experience</th>
					<th>Specialisation</th>
					<th>Category</th>
				</tr>
			
			<?php
			foreach($fthr as $row) {
				$employee_id=$row['employee_id'];
				$document=$row['document'];
				echo "<tr>";
				echo "<td>".$row['names']."</td>";
				echo "<td>".$row['gender'];
				if ($row['status']==date("d/m/Y")) {
					echo "&nbsp<i style='font-size: 11px; background-color: #ff0000; color:#fff; padding: 2px;'>new</i>";
				}
				echo "</td>";
				echo "<td>".$row['qualification']."</td>";
				echo "<td>".$row['experience']."</td>";
				echo "<td>".$row['specialisation']."</td>";
				echo "<td>".$row['category']."</td>";
			}
			?>
			</table>
		</div>
		<?php	
		
	}

	
	public function FetchStoremanagers()
	{
		$fthr=$this->icon->query("SELECT * FROM employees_tb WHERE role='Storemanagers' ORDER BY employee_id DESC");
		?>
		<div style="height: 500px; overflow: auto; text-transform: capitalize;">
			<table class="table table-striped table-bordered table-responsive table-hover small">
				<tr>
					<th>Names</th>
					<th>Gender</th>
					<th>Qualifications</th>
					<th>Experience</th>
					<th>Specialisation</th>
					<th>Category</th>
				</tr>
			
			<?php
			foreach($fthr as $row) {
				$employee_id=$row['employee_id'];
				$document=$row['document'];
				echo "<tr>";
				echo "<td>".$row['names']."</td>";
				echo "<td>".$row['gender'];
				if ($row['status']==date("d/m/Y")) {
					echo "&nbsp<i style='font-size: 11px; background-color: #ff0000; color:#fff; padding: 2px;'>new</i>";
				}
				echo "</td>";
				echo "<td>".$row['qualification']."</td>";
				echo "<td>".$row['experience']."</td>";
				echo "<td>".$row['specialisation']."</td>";
				echo "<td>".$row['category']."</td>";
			}
			?>
			</table>
		</div>
		<?php	
		
	}

	
	public function FetchCateringservices()
	{
		$fthr=$this->icon->query("SELECT * FROM employees_tb WHERE role='Cateringservices' ORDER BY employee_id DESC");
		?>
		<div style="height: 500px; overflow: auto; text-transform: capitalize;">
			<table class="table table-striped table-bordered table-responsive table-hover small">
				<tr>
					<th>Names</th>
					<th>Gender</th>
					<th>Qualifications</th>
					<th>Experience</th>
					<th>Specialisation</th>
					<th>Category</th>
				</tr>
			
			<?php
			foreach($fthr as $row) {
				$employee_id=$row['employee_id'];
				$document=$row['document'];
				echo "<tr>";
				echo "<td>".$row['names']."</td>";
				echo "<td>".$row['gender'];
				if ($row['status']==date("d/m/Y")) {
					echo "&nbsp<i style='font-size: 11px; background-color: #ff0000; color:#fff; padding: 2px;'>new</i>";
				}
				echo "</td>";
				echo "<td>".$row['qualification']."</td>";
				echo "<td>".$row['experience']."</td>";
				echo "<td>".$row['specialisation']."</td>";
				echo "<td>".$row['category']."</td>";
			}
			?>
			</table>
		</div>
		<?php	
		
	}

	public function FetchTourguides()
	{
		$fthr=$this->icon->query("SELECT * FROM employees_tb WHERE role='Tourguides' ORDER BY employee_id DESC");
		?>
		<div style="height: 500px; overflow: auto; text-transform: capitalize;">
			<table class="table table-striped table-bordered table-responsive table-hover small">
				<tr>
					<th>Names</th>
					<th>Gender</th>
					<th>Qualifications</th>
					<th>Experience</th>
					<th>Specialisation</th>
					<th>Category</th>
				</tr>
			
			<?php
			foreach($fthr as $row) {
				$employee_id=$row['employee_id'];
				$document=$row['document'];
				echo "<tr>";
				echo "<td>".$row['names']."</td>";
				echo "<td>".$row['gender'];
				if ($row['status']==date("d/m/Y")) {
					echo "&nbsp<i style='font-size: 11px; background-color: #ff0000; color:#fff; padding: 2px;'>new</i>";
				}
				echo "</td>";
				echo "<td>".$row['qualification']."</td>";
				echo "<td>".$row['experience']."</td>";
				echo "<td>".$row['specialisation']."</td>";
				echo "<td>".$row['category']."</td>";
			}
			?>
			</table>
		</div>
		<?php	
		
	}

	public function FetchAspothers()
	{
		$fthr=$this->icon->query("SELECT * FROM employees_tb WHERE role='Aspothers' ORDER BY employee_id DESC");
		?>
		<div style="height: 500px; overflow: auto; text-transform: capitalize;">
			<table class="table table-striped table-bordered table-responsive table-hover small">
				<tr>
					<th>Names</th>
					<th>Gender</th>
					<th>Qualifications</th>
					<th>Experience</th>
					<th>Specialisation</th>
					<th>Category</th>
				</tr>
			
			<?php
			foreach($fthr as $row) {
				$employee_id=$row['employee_id'];
				$document=$row['document'];
				echo "<tr>";
				echo "<td>".$row['names']."</td>";
				echo "<td>".$row['gender'];
				if ($row['status']==date("d/m/Y")) {
					echo "&nbsp<i style='font-size: 11px; background-color: #ff0000; color:#fff; padding: 2px;'>new</i>";
				}
				echo "</td>";
				echo "<td>".$row['qualification']."</td>";
				echo "<td>".$row['experience']."</td>";
				echo "<td>".$row['specialisation']."</td>";
				echo "<td>".$row['category']."</td>";
			}
			?>
			</table>
		</div>
		<?php	
		
	}

	
	public function FetchDomestichelpers()
	{
		$fthr=$this->icon->query("SELECT * FROM employees_tb WHERE role='Domestichelpers' ORDER BY employee_id DESC");
		?>
		<div style="height: 500px; overflow: auto; text-transform: capitalize;">
			<table class="table table-striped table-bordered table-responsive table-hover small">
				<tr>
					<th>Names</th>
					<th>Gender</th>
					<th>Qualifications</th>
					<th>Experience</th>
					<th>Specialisation</th>
					<th>Category</th>
				</tr>
			
			<?php
			foreach($fthr as $row) {
				$employee_id=$row['employee_id'];
				$document=$row['document'];
				echo "<tr>";
				echo "<td>".$row['names']."</td>";
				echo "<td>".$row['gender'];
				if ($row['status']==date("d/m/Y")) {
					echo "&nbsp<i style='font-size: 11px; background-color: #ff0000; color:#fff; padding: 2px;'>new</i>";
				}
				echo "</td>";
				echo "<td>".$row['qualification']."</td>";
				echo "<td>".$row['experience']."</td>";
				echo "<td>".$row['specialisation']."</td>";
				echo "<td>".$row['category']."</td>";
			}
			?>
			</table>
		</div>
		<?php	
		
	}


	public function FetchCleaners()
	{
		$fthr=$this->icon->query("SELECT * FROM employees_tb WHERE role='Cleaners' ORDER BY employee_id DESC");
		?>
		<div style="height: 500px; overflow: auto; text-transform: capitalize;">
			<table class="table table-striped table-bordered table-responsive table-hover small">
				<tr>
					<th>Names</th>
					<th>Gender</th>
					<th>Qualifications</th>
					<th>Experience</th>
					<th>Specialisation</th>
					<th>Category</th>
				</tr>
			
			<?php
			foreach($fthr as $row) {
				$employee_id=$row['employee_id'];
				$document=$row['document'];
				echo "<tr>";
				echo "<td>".$row['names']."</td>";
				echo "<td>".$row['gender'];
				if ($row['status']==date("d/m/Y")) {
					echo "&nbsp<i style='font-size: 11px; background-color: #ff0000; color:#fff; padding: 2px;'>new</i>";
				}
				echo "</td>";
				echo "<td>".$row['qualification']."</td>";
				echo "<td>".$row['experience']."</td>";
				echo "<td>".$row['specialisation']."</td>";
				echo "<td>".$row['category']."</td>";
			}
			?>
			</table>
		</div>
		<?php	
		
	}


	public function FetchOperationalworkers()
	{
		$fthr=$this->icon->query("SELECT * FROM employees_tb WHERE role='Operationalworkers' ORDER BY employee_id DESC");
		?>
		<div style="height: 500px; overflow: auto; text-transform: capitalize;">
			<table class="table table-striped table-bordered table-responsive table-hover small">
				<tr>
					<th>Names</th>
					<th>Gender</th>
					<th>Qualifications</th>
					<th>Experience</th>
					<th>Specialisation</th>
					<th>Category</th>
				</tr>
			
			<?php
			foreach($fthr as $row) {
				$employee_id=$row['employee_id'];
				$document=$row['document'];
				echo "<tr>";
				echo "<td>".$row['names']."</td>";
				echo "<td>".$row['gender'];
				if ($row['status']==date("d/m/Y")) {
					echo "&nbsp<i style='font-size: 11px; background-color: #ff0000; color:#fff; padding: 2px;'>new</i>";
				}
				echo "</td>";
				echo "<td>".$row['qualification']."</td>";
				echo "<td>".$row['experience']."</td>";
				echo "<td>".$row['specialisation']."</td>";
				echo "<td>".$row['category']."</td>";
			}
			?>
			</table>
		</div>
		<?php	
		
	}


	public function FetchOthers()
	{
		$fthr=$this->icon->query("SELECT * FROM employees_tb WHERE role='Others' ORDER BY employee_id DESC");
		?>
		<div style="height: 500px; overflow: auto; text-transform: capitalize;">
			<table class="table table-striped table-bordered table-responsive table-hover small">
				<tr>
					<th>Names</th>
					<th>Gender</th>
					<th>Qualifications</th>
					<th>Experience</th>
					<th>Specialisation</th>
					<th>Category</th>
				</tr>
			
			<?php
			foreach($fthr as $row) {
				$employee_id=$row['employee_id'];
				$document=$row['document'];
				echo "<tr>";
				echo "<td>".$row['names']."</td>";
				echo "<td>".$row['gender'];
				if ($row['status']==date("d/m/Y")) {
					echo "&nbsp<i style='font-size: 11px; background-color: #ff0000; color:#fff; padding: 2px;'>new</i>";
				}
				echo "</td>";
				echo "<td>".$row['qualification']."</td>";
				echo "<td>".$row['experience']."</td>";
				echo "<td>".$row['specialisation']."</td>";
				echo "<td>".$row['category']."</td>";
			}
			?>
			</table>
		</div>
		<?php	
		
	}
	
}
$icox = new Corex();
?>