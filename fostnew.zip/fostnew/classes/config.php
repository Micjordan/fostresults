<?php
session_start();
class Config
{
	protected $icon;
	function __construct()	{
		
		try {
			@define('DB_HOST', 'localhost');
			@define('DB_USER', 'root');
			@define('DB_PASSWORD', '');
			@define('DB_DATABASE', 'fostresults2');
			$this->icon = new mysqli(DB_HOST,DB_USER,DB_PASSWORD,DB_DATABASE);
		} catch (Exception $e) {
			echo $e->getMessage();
		}
	}
}
?>

 <?php
	/* ob_start();
	session_start();
	$conn= mysqli_connect('localhost', 'root','f0s31nt3st');
	mysqli_select_db($conn, 'fostresults2');
	if (!isset($_SESSION["id"])) {
		echo "<script>window.open('index.php','_self')</script>";
	} */
?>
